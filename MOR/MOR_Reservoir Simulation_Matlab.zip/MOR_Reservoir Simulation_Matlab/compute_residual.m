function [Residual] = compute_residual(Transmisibility, Accumulation, Wells, Solution)

Acc     = Accumulation.Acc;
Trans   = Transmisibility.T - Wells.Q;
qs      = Wells.q;

%====================================

Ppast   = Solution.Ppast;
Swpast  = Solution.Swpast;
P       = Solution.Pcurrent;
Sw      = Solution.Swcurrent;
A       = Acc;
T       = Trans;
Xpast   = [Ppast; Swpast];
X   	= [P; Sw];
q       = qs;

%====================================
Residual   = T*X - A * (X - Xpast) + q;


end