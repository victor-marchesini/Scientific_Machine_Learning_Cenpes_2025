function [Geometry, Discretization, Fluid, Rock, Wells, Conditions, Constants] = initialize

%-------------------------------------
% Final Project Case Study
%-------------------------------------

%=================================
% 1) INPUT DATA
%=================================
Nx      = 45;
Ny      = 45;
Nz      = 1;
Nt      = Nx*Ny*Nz;   % [-]
%=================================
% a) Geometry
%=================================
Geometry.Lx = 32.808*Nx; % [ft]
Geometry.Ly = 32.808*Ny; % [ft]
Geometry.Lz = 32.808*Nz; % [ft] 

%=================================
% b) Discretization
%=================================
% Spatial
Discretization.Nx   = Nx;   % [-]
Discretization.Ny   = Ny;   % [-]
Discretization.Nz   = Nz;   % [-]
Discretization.Nt   = Nt;
Discretization.n    = 1;
Discretization.Dt   = 0.1;  % [Day]
Discretization.Tsim = 1000;  % [Day]
Discretization.Formulation = 'IMPES'; 
% Discretization.Formulation = 'IMPLICIT'; 
% Discretization.Solver = 'GMRES'; 
%Discretization.Solver = 'CG'; 
Discretization.Solver = 'GE'; % Gauss Elimination

%=================================
% Permeability
%=================================
load('TRUE_PERM');
%-----------------
Rock.Kx = TRUE_PERM(1:Nx,1:Ny)/1000;    % [Darcy]
Rock.Ky = Rock.Kx;

%===================================
% Porousity
%===================================
Rock.poro     = 0.20;     % [fraction]

%=================================
% c) Properties
%=================================
Fluid.P_ref    = 2800;     % [psi]
Fluid.Cw       = 3e-6;     % [psi-1]
Fluid.Co       = 1e-5;     % [psi-1]
Fluid.Uw_table = ...
    [400    1
    2800    1
    5600    1];                 % [cp]
Fluid.Uo_table = ...
    [400  1.17
    800   1.14
    1200  1.11
    1600  1.08
    2000  1.06
    2400  1.03
    2800  1
    3200  0.98
    3600  0.95
    4000  0.94
    4400  0.92
    4800  0.91
    5200  0.90
    5600  0.89];                % [cp]
Fluid.Bo_table = ...
    [400  1.012
    800   1.009
    1200  1.005
    1600  1.001
    2000  0.996
    2400  0.99
    2800  0.988
    3200  0.985
    3600  0.98
    4000  0.975
    4400  0.97
    4800  0.965
    5200  0.96
    5600  0.955];               % [rbbl/stb]

Fluid.Bw_ref   = 1;        % [RB/STB] 

Rock.krw_table  = ...
    [0   0
    0.1  0.0001
    0.2  0.0025
    0.3  0.023
    0.4  0.0842
    0.5  0.2115
    0.6  0.4319
    0.7  0.774
    0.75 0.9999
    0.8  1
    0.9  1
    1    1]; % [-]

Rock.kro_table  = ...
    [0   0
    0.1  0
    0.2  0
    0.25 0.0001
    0.3  0.0059
    0.4  0.0533
    0.5  0.1479
    0.6  0.2899
    0.7  0.4793
    0.8  0.716
    0.9  1
    1    1]; % [-]

%=================================
% d) Wells
%=================================
Wells.rw        = 0.2915; % [ft]
Wells.Skin      = 0;
Wells.Qinj      = 800;  % [STB/day]
Wells.Pwf_pro   = [2900,2900,2900,2900]';  % [psi]

Wells.Qinj_ji   = [ceil(Nx/2),ceil(Ny/2)]; % [ix,jy]
Wells.Qpro_ji   = [1,1;1,Ny;Nx,1;Nx,Ny]; % [ix,jy]

Wells.Qinj_ind  = sub2ind([Nx Ny],Wells.Qinj_ji(:,1) ,Wells.Qinj_ji(:,2));
Wells.Qpro_ind  = sub2ind([Nx Ny],Wells.Qpro_ji(:,1) ,Wells.Qpro_ji(:,2));

%=================================
% e) Initial conditions
%=================================
Conditions.Initial.Pi  = 3000; % [psi]
Conditions.Initial.Swi = 0.1;    % [-]
Conditions.Initial.Soi = 0.9;    % [-]

%=================================
% f) Constants (conversion factors) 
%=================================
Constants.Bc = 1.127;
Constants.Ac = 5.614583;


end