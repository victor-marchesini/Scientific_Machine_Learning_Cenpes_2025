function Discretization = compute_time(Discretization)

time    = Discretization.time;

%===================================
if time(end)<1
    Dt = 0.2;
 
elseif  time(end)<4
    Dt = 1;
    
elseif  time(end)<40
    Dt = 4;
    
elseif  time(end)<400
    Dt = 10;

elseif  time(end)<600
    Dt = 10;
    
elseif  time(end)<1000
    Dt = 10;
    
else
    
    Dt = 2;
end

%======================================
Discretization.Dt           = Dt;
Discretization.n            = Discretization.n+1;
Discretization.time(end+1)  = time(end)+Dt;
end