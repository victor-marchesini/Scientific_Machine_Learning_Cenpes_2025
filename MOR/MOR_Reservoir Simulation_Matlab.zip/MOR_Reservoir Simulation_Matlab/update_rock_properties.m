function Rock = update_rock_properties(Rock,Solution)

P  = Solution.Pcurrent;
Sw = Solution.Swcurrent;

%============================
% Update components 
% [phi, dphi]                 = compute_porousity(Rock,P);
[kro,krw,dkro,dkrw]         = compute_relative_permeability(Rock,Sw);

%=======================
Rock.kro  = kro;
Rock.krw  = krw;
Rock.dkro = dkro;
Rock.dkrw = dkrw;

end