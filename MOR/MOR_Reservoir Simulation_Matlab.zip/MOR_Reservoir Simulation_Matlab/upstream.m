function y= upstream( x1, x2, P1, P2)

I       = find(P1<P2);
x1(I)   = x2(I);
y       = x1;
end