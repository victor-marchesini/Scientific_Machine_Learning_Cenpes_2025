function varargout = compute_volumetric_factor(Properties,P)

[bo, bw]        = compute_FVF_inv(Properties,P);
varargout{1}    = bo;
varargout{2}    = bw;

if nargout > 2,
    [dbo, dbw ddbo ddbw]      = compute_derivatiest(@(P) compute_FVF_inv(Properties,P),P);
    varargout{3}    = dbo;
    varargout{4}    = dbw;
    %     varargout{4}    = -Properties.Cw*Bw;
    if nargout > 4,
        varargout{5}    = ddbo;
        varargout{6}    = ddbw;
    end
end

end

function [Bo, Bw] = compute_FVF(Properties,P)

P_ref   = Properties.P_ref;
Bw_ref  = Properties.Bw_ref;
Cw      = Properties.Cw;
X       = Cw.*(P - P_ref);
Bw      = Bw_ref./(1 + X + X.^2);

%============================
Bo_table= Properties.Bo_table;
Bo      = property_interp(Bo_table(:,1),Bo_table(:,2),P); % [rbbl/stb]

%============================
    
end

function [bo bw] = compute_FVF_inv(Properties,P)

[Bo,Bw] = compute_FVF(Properties,P);
bo      = 1./Bo;
bw      = 1./Bw;

end