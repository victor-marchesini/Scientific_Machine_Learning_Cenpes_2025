% visualize properties
close all; clear;
[Geometry, Discretization, Properties, Wells, Conditions, Constants] = initialize;
%====================================================================================
P       = linspace(2500,3500,50)';
Sw      = linspace(0,1,50)';

%================================================================
Solution.Pcurrent   = P;
Solution.Swcurrent  = Sw;
[Properties]        = update_properties(Properties,Solution);
[Mobility]          = compute_mobility(Properties);

%================================================================
bo      = Properties.bo;
bw      = Properties.bw;
dbo     = Properties.dbo;
dbw     = Properties.dbw;
Uo      = Properties.Uo;
Uw      = Properties.Uw;
dUo     = Properties.dUo;
dUw     = Properties.dUw;
kro     = Properties.kro;
krw     = Properties.krw;
dkro    = Properties.dkro;
dkrw    = Properties.dkrw;

fro     = Mobility.fro;
frw     = Mobility.frw;
dfrodP  = Mobility.dfrodP;
dfrwdP  = Mobility.dfrwdP;
dfrodSw = Mobility.dfrodSw;
dfrwdSw = Mobility.dfrwdSw;

%============================================================================================
figure();
subplot(211); plot(P,[bo, bw]); legend('bo','bw'); xlabel('P'); title('FVF')
subplot(212); plot(P,[dbo, dbw]); legend('dbo','dbw'); xlabel('P'); title('FVF derivative')
figure();
subplot(211); plot(P,[Uo, Uw]); legend('Uo','Uw'); xlabel('P'); title('Viscosity');
subplot(212); plot(P,[dUo, dUw]); legend('dUo','dUw'); xlabel('P'); title('Viscosity derivative');
figure();
subplot(211); plot(Sw,[kro, krw]); legend('kro','krw'); xlabel('Sw'); title('Relative permeability');
subplot(212); plot(Sw,[dkro, dkrw]); legend('dkro','dkrw'); xlabel('Sw'); title('Relative permeability derivative');
figure();
plot(P,[fro, frw]); legend('\lambda_{ro}','\lambda_{rw}'); xlabel('Sw'); title('Mobility');
figure();
subplot(211); plot(P,[dfrodP, dfrwdP]); legend('dfro','dfrw'); xlabel('P'); title('d\lambda/dP');
subplot(212); plot(Sw,[dfrodSw, dfrwdSw]); legend('dfro','dfrw'); xlabel('Sw'); title('d\lambda/dSw');