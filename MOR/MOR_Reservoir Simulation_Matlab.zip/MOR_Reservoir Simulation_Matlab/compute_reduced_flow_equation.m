function [Equations] = compute_reduced_flow_equation(Transmisibility, Accumulation, Wells, Solution, Reduction)

Acc     = Accumulation.Acc;
Trans   = Transmisibility.T - Wells.Q;
qs      = Wells.q;

%====================================
if strcmp(Reduction.Mode,'POD')
    Psi = Reduction.BasisPOD.Psi;
    rP  = Solution.rPcurrent;
    rSw = Solution.rSwcurrent;
    A   = Psi'*Acc*Psi;
    T   = Psi'*Trans*Psi;
    X   = [rP; rSw];
    q   = Psi'*qs;
   
elseif strcmp(Reduction.Mode,'DEIM')
    Psi     = Reduction.BasisPOD.Psi;
    rP      = Solution.rPcurrent;
    rSw     = Solution.rSwcurrent;
    Phi_Tx  = Reduction.BasisDEIM.Phi_Tx;
    U_Tx    = Reduction.BasisDEIM.U_Tx;
    Phi_Ax  = Reduction.BasisDEIM.Phi_Ax;
    U_Ax    = Reduction.BasisDEIM.U_Ax;
    A       = Psi'*U_Ax*Acc(Phi_Ax,:)*Psi;
    T       = Psi'*U_Tx*Trans(Phi_Tx,:)*Psi;
    X       = [rP; rSw];
    q       = Psi'*qs;
    
else % [Full Model]
    P   = Solution.Pcurrent;
    Sw  = Solution.Swcurrent;
    A   = Acc;
    T   = Trans;
    X   = [P; Sw];
    q   = qs;
end

%====================================
Equations.Right = - A * X - q;
Equations.Left  = T - A;
end