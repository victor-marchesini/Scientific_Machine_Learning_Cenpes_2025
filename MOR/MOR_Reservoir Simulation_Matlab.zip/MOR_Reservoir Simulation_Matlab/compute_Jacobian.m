function [Jac, Jacobians] = compute_Jacobian(Discretization, Constants, Fluid, Rock, Mobility, Wells, Accumulation, Transmisibility, Solution)

[Wells]             = compute_source_derivative(Discretization, Mobility, Wells, Solution);
[Accumulation]      = compute_accumulation_derivative(Discretization, Constants, Fluid, Rock, Accumulation, Solution);
[Transmisibility]   = compute_transmisibility_derivative(Discretization, Rock, Mobility, Solution, Transmisibility);

Acc     = Accumulation.Acc;
T       = Transmisibility.T;
Q       = Wells.Q;
dAcc    = Accumulation.dAcc;
dT      = Transmisibility.dT;
dQ      = Wells.dQ;


%====================================
Jac     = T - Q - Acc + dT - dQ - dAcc ; 

%% Saving derivatives for State Stace
Jacobians.dAcc	= dAcc;
Jacobians.dT      = dT;
Jacobians.dQ      = dQ;
end