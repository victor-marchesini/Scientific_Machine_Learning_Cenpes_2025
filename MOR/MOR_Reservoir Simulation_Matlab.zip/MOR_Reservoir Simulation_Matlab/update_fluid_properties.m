function Fluid = update_fluid_properties(Fluid,Solution)

P  = Solution.Pcurrent;
Sw = Solution.Swcurrent;

% P  = 3000*ones(length(Sw),1);
%============================
% Update components 
[bo bw dbo dbw ddbo ddbw]   = compute_volumetric_factor(Fluid,P);
[Uo,Uw,dUo,dUw]             = compute_viscosity(Fluid,P);

%=======================
Fluid.bo   = bo;
Fluid.bw   = bw;
Fluid.dbo  = dbo;
Fluid.dbw  = dbw;
Fluid.ddbo = ddbo;
Fluid.ddbw = ddbw;
Fluid.Uo   = Uo;
Fluid.Uw   = Uw;
Fluid.dUo  = dUo;
Fluid.dUw  = dUw;



