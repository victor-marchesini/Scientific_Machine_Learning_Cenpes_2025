function [Mobility]= compute_mobility(Fluid,Rock)

bo      = Fluid.bo;
bw      = Fluid.bw;
dbo     = Fluid.dbo;
dbw     = Fluid.dbw;
Uo      = Fluid.Uo;
Uw      = Fluid.Uw;
dUo     = Fluid.dUo;
dUw     = Fluid.dUw;
kro     = Rock.kro;
krw     = Rock.krw;
dkro    = Rock.dkro;
dkrw    = Rock.dkrw;

%=================================================
fro     = compute_mob(kro,bo,Uo);
frw     = compute_mob(krw,bw,Uw);

%=================================================
dfrodP      = compute_dmob_dP(kro,bo,Uo,dbo,dUo);
dfrwdP      = compute_dmob_dP(krw,bw,Uw,dbw,dUw);
dfrodSw     = compute_dmob_dSw(dkro,bo,Uo);
dfrwdSw     = compute_dmob_dSw(dkrw,bw,Uw);

%=================================================
Mobility.fro        = fro;
Mobility.frw        = frw;
Mobility.dfrodP     = dfrodP;
Mobility.dfrwdP     = dfrwdP;
Mobility.dfrodSw    = dfrodSw;
Mobility.dfrwdSw    = dfrwdSw;


end

function y = compute_mob(kr,b,U)
    y   = kr.*b./U;
end

function dydp = compute_dmob_dP(kr,b,U,db,dU)
    dydp    = kr.*(db.*U-dU.*b)./(U.^2);
end

function dyds = compute_dmob_dSw(dkr,b,U)
    dyds    = dkr.*b./U;
end


