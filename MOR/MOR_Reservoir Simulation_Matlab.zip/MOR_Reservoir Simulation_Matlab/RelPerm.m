function varargout = RelPerm(s, varargin)
% Find the relative permeability 
Sw                  = s(:,1);
So                  = 1-Sw;
Swr                 = 0.1;
Sor                 = 0.2;
Swmin               = Swr;
Somin               = Sor;
Swmax               = 1-Sor;
Somax               = 1-Swr;
Krws                = 0.08;
Kros                = 0.70;

Krw                 = Krws*((Sw-Swr)./(1-Sor-Swr)).^2;
Krw(find(Sw<Swmin)) = 0;
Krw(find(Sw>Swmax)) = Krws;

Kro                 = Kros*((So-Sor)./(1-Sor-Swr)).^3;
Kro(find(So<Somin)) = 0;
Kro(find(So>Somax)) = Kros;

varargout{1}       = [Krw, Kro];

if nargout > 1,  
    dKrw                 = 2*Krws*((Sw-Swr)./(1-Sor-Swr));
    dKrw(find(Sw<Swmin)) = 0;
    dKrw(find(Sw>Swmax)) = 0;
    dKro                 = 3*Kros*((So-Sor)./(1-Sor-Swr)).^2;
    dKro(find(So<Somin)) = 0;
    dKro(find(So>Somax)) = 0;
    varargout{2} = [dKrw, dKro];
end

end


