function [u,m] = CG_alex(A, f, u0, tol, max)

r0 = f - A*u0;
p = r0;
d0 = dot(r0,r0);
error = 1e3;
m = 0;

while error>tol
    
    m = m + 1;
    a    = A*p;
    
    alfa = d0 / dot(a,p); 
    u = u0 + alfa * p;
    r = r0 - alfa * a;
    d = dot(r,r);
    
    p = r + (d/d0)*p;
    d0 = d; u0 = u; r0 = r;

    error = norm(f-A*u,2) / norm(f,2);
    
    if m==max error = 0; end
    
end

return