function C_bar = compute_linearized_C(Discretization,Mobility, Wells, C, Solution)
% y = [p_inj_well ; q_prod_well]
Nt          = Discretization.Nt;
J_pro       = Wells.J_pro;
J_inj       = Wells.J_inj;
Pwf_pro     = Wells.Pwf_pro;
Qinj        = Wells.Qinj;
Qinj_ind    = Wells.Qinj_ind;
Qpro_ind    = Wells.Qpro_ind;
Npro        = Wells.Npro;
Ninj        = Wells.Ninj;
Nwells      = Npro+Ninj;

mob_o	= Mobility.fro;
mob_w 	= Mobility.frw;
dmodp   = Mobility.dfrodP;
dmwdp   = Mobility.dfrwdP;
dmods   = Mobility.dfrodSw;
dmwds   = Mobility.dfrwdSw;

p = Solution.P;

%% Fractional flow - only for producers wells
mob_total	= mob_o + mob_w;
Fr_o        = mob_o./mob_total;
Fr_w        = mob_w./mob_total;

dFr_o_dp = dmodp.*mob_total - mob_o.* (dmodp + dmwdp);
dFr_w_dp = dmwdp.*mob_total - mob_w.* (dmodp + dmwdp);
dFr_o_ds = dmods.*mob_total - mob_o.* (dmods + dmwds);
dFr_w_ds = dmwds.*mob_total - mob_w.* (dmods + dmwds);

%% d(Fr*Mobility)/dx
dFrmo_dp = dFr_o_dp.*mob_o + Fr_o.*dmodp;
dFrmw_dp = dFr_w_dp.*mob_w + Fr_w.*dmwdp;
dFrmo_ds = dFr_o_ds.*mob_o + Fr_o.*dmods;
dFrmw_ds = dFr_w_ds.*mob_w + Fr_w.*dmwds;

%% Bulding Matrices dC_dx and dD_dx
dCdp_prod_o = spalloc(Npro,Nt,Npro); 
dCdp_prod_w = spalloc(Npro,Nt,Npro); 
dCdp_inje_w = spalloc(Ninj,Nt,Ninj); 

dCds_prod_o = spalloc(Npro,Nt,Npro); 
dCds_prod_w = spalloc(Npro,Nt,Npro); 
dCds_inje_w = spalloc(Ninj,Nt,Ninj); 

dDdp_prod_o = spalloc(Npro,Nt,Npro); 
dDdp_prod_w = spalloc(Npro,Nt,Npro);
dDdp_inje_w = spalloc(Ninj,Nt,Ninj); 

dDds_prod_o = spalloc(Npro,Nt,Npro); 
dDds_prod_w = spalloc(Npro,Nt,Npro); 
dDds_inje_w = spalloc(Ninj,Nt,Ninj); 

%---------------------
% Producer wells => q_prod_well = [q_prod_well_o; q_prod_well_w]
%---------------------
dCdp_prod_o(:,Qpro_ind)	= - diag(J_pro.*dFrmo_dp(Qpro_ind).*p(Qpro_ind));
dCdp_prod_w(:,Qpro_ind)	= - diag(J_pro.*dFrmw_dp(Qpro_ind).*p(Qpro_ind));
dCds_prod_o(:,Qpro_ind)	= - diag(J_pro.*dFrmo_ds(Qpro_ind).*p(Qpro_ind));
dCds_prod_w(:,Qpro_ind)	= - diag(J_pro.*dFrmw_ds(Qpro_ind).*p(Qpro_ind));

dDdp_prod_o(:,Qpro_ind)	= diag(J_pro.*dFrmo_dp(Qpro_ind).*Pwf_pro);
dDdp_prod_w(:,Qpro_ind)	= diag(J_pro.*dFrmw_dp(Qpro_ind).*Pwf_pro);
dDds_prod_o(:,Qpro_ind)	= diag(J_pro.*dFrmo_ds(Qpro_ind).*Pwf_pro);
dDds_prod_w(:,Qpro_ind)	= diag(J_pro.*dFrmw_ds(Qpro_ind).*Pwf_pro);

%---------------------
% Injector wells => q_prod_well
%---------------------
FrMob_w_inv = (Fr_w(Qinj_ind).*mob_w(Qinj_ind))^(-2);

dDdp_inje_w(:,Qinj_ind)	= - diag(FrMob_w_inv./J_inj.*dFrmw_dp(Qinj_ind).*Qinj);
dDds_inje_w(:,Qinj_ind)	= - diag(FrMob_w_inv./J_inj.*dFrmw_ds(Qinj_ind).*Qinj);

%% Compiling Matrices
dCdp = [dCdp_prod_o' dCdp_prod_w' dCdp_inje_w']';
dCds = [dCds_prod_o' dCds_prod_w' dCds_inje_w']';
dC_dx = [dCdp dCds];

dDdp = [dDdp_prod_o' dDdp_prod_w' dDdp_inje_w']';
dCds = [dDds_prod_o' dDds_prod_w' dDds_inje_w']';
dD_dx = [dDdp dCds];

C_bar = C + dC_dx + dD_dx;
return