%================================
% POD Model Order Reduction
%================================
clear all; close all;
load('FullSolution.mat');

%============================================================================================
[Geometry, Discretization, Fluid, Rock, Wells, Conditions, Constants] = initialize; 
%============================================================================================
Reduction.Mode      = 'POD';
Reduction.nrP       = 60;    %60
Reduction.nrSw      = 80;    %80
[Reduction]                            = compute_POD_basis(Reduction, FullSolution);
[Discretization, Wells, PODSolution]   = pre_processing(Geometry, Discretization, Rock, Wells, Conditions, Constants, Reduction);
[Rock]                                 = compute_geopart_avg(Discretization, Rock, PODSolution, Constants);


%%
%====================================
% Time loop
%====================================
h = waitbar(0,'1','Name','Running simulation...',...
            'CreateCancelBtn',...
            'setappdata(gcbf,''canceling'',1)');
setappdata(h,'canceling',0);

Discretization.n    = 1;
Discretization.time = 0;
ResidulNorm         = 1;
PODSolution.Update  = 1;
iteration           = 0;
tic
while Discretization.time(end)<Discretization.Tsim
    while PODSolution.Update > 1e-6 
        [Fluid]             = update_fluid_properties(Fluid,PODSolution);
        [Rock]              = update_rock_properties(Rock,PODSolution);
        [Mobility]          = compute_mobility(Fluid,Rock);
        [Wells]             = compute_source(Discretization, Mobility, Wells);
        [Accumulation]      = compute_accumulation(Discretization, Constants, Fluid, Rock, PODSolution);
        [Transmisibility]   = compute_transmisibility(Discretization, Rock, Mobility, PODSolution);
        [Residual]          = compute_residual(Transmisibility, Accumulation, Wells, PODSolution);
        [Jac]               = compute_Jacobian(Discretization, Constants, Fluid, Rock, Mobility, Wells, Accumulation, Transmisibility, PODSolution);
        [Equations]         = compute_flow_vector_implicit(Residual, Jac, Reduction);
        [PODSolution]       = compute_pressure_saturation_implicit(Discretization, Reduction, Equations, PODSolution, 'GE');
        ResidulNorm         = norm(Residual,inf);
        iteration           = iteration+1;
    end
    PODSolution.Update      = 1;
    ResidulNorm             = 1;
    iteration               = 0;
    [Wells, PODSolution]    = save_results(Mobility,Wells,PODSolution);
    [Discretization]        = compute_time(Discretization);
%     [FullSolution]          = NonlinFuncEval(Discretization, Transmisibility, Accumulation, FullSolution); % Evaluates nonlinear functions at the resutls to be used in DEIM

    % Check for Cancel button press
    if getappdata(h,'canceling')
        break
    end
    % Report current estimate in the waitbar's message field
    waitbar(Discretization.time(end)/Discretization.Tsim,h,sprintf('%2.1f',100*Discretization.time(end)/Discretization.Tsim));

  
end   
POD_t       = toc

delete(h);

errPOD_Po   = norm(PODSolution.P-FullSolution.P,'fro')^2/mean(mean(PODSolution.P))
errPOD_Sw   = norm(PODSolution.Sw-FullSolution.Sw,'fro')^2
  
visualize_results(Discretization,Rock,Wells,Reduction,PODSolution);
% save PODSolution.mat PODSolution
save PODReduction.mat Reduction

Equations.JacSizes
