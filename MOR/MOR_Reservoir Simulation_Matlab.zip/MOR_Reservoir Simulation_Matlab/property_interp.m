function y = property_interp(Xref,Yref,x)
y         = interp1(Xref,Yref,x,'pchip');
I         = find (x < Xref(1));
y(I)      = Yref(1);
I         = find (x > Xref(end));
y(I)      = Yref(end);
end