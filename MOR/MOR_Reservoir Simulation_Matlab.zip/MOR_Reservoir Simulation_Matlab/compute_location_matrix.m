function L = compute_location_matrix(Discretization,Mobility, Wells)

%% Sources/sinks => Control Form
% Defining u = [Wells.Pwf_pro ; Wells.Qinj]
% we should find a matrix F such that F*u = q;
Nt          = Discretization.Nt;
fro         = Mobility.fro;
frw         = Mobility.frw;
J_pro       = Wells.J_pro;
Qinj_ind    = Wells.Qinj_ind;
Qpro_ind    = Wells.Qpro_ind;
Npro        = Wells.Npro;
Ninj        = Wells.Ninj;

Lprod_o = spalloc(Nt,Npro,Npro);
Lprod_w = spalloc(Nt,Npro,Npro);
Linje_o = spalloc(Nt,Ninj,Ninj);
Linje_w = spalloc(Nt,Ninj,Ninj);

%---------------------
% Producer wells
%---------------------
Lprod_o(Qpro_ind, :)    = diag(J_pro.*fro(Qpro_ind));
Lprod_w(Qpro_ind, :)    = diag(J_pro.*frw(Qpro_ind));

%---------------------
% Producer wells
%---------------------
Linje_w(Qinj_ind, :) =  1;

%=========================================
L = [Lprod_o Linje_o ;Lprod_w  Linje_w];
% you can check if F*u == q; where u = [Wells.Pwf_pro ; Wells.Qinj]

end