function [Prop_xpos Prop_xneg Prop_ypos Prop_yneg] = property_avg(Discretization, Solution, Prop_x, Prop_y, type)

%=================================
% Getting the parameters from data structures
%=================================
Nx      = Discretization.Nx;
Ny      = Discretization.Ny;
Nz      = Discretization.Nz;
Nt      = Discretization.Nt;
x_neg   = Discretization.x_neg;
x_pos   = Discretization.x_pos;
y_neg   = Discretization.y_neg;
y_pos   = Discretization.y_pos;
z_neg   = Discretization.z_neg;
z_pos   = Discretization.z_pos;

P       = Solution.Pcurrent;
%------------------

% if nargin==4
%     Prop_y  = Prop_x;
%     type    = varargin{4};
% elseif nargin==5
%     Prop_y  = varargin{4,:};
%     type    = varargin{5};
% end
%------------------------------------------------------------------
AvgProp_x  = zeros(Nx+1,Ny,Nz);
AvgProp_y  = zeros(Nx,Ny+1,Nz);

if strcmp(type, 'Mean')
    AvgProp_x(2:Nx,:,:)  = mean_average(Prop_x(x_neg), Prop_x(x_pos));
    AvgProp_y(:,2:Ny,:)  = mean_average(Prop_y(y_neg), Prop_y(y_pos));
    
elseif strcmp(type, 'Harmonic')
    AvgProp_x(2:Nx,:,:)  = harmonic_average(Prop_x(x_neg), Prop_x(x_pos));
    AvgProp_y(:,2:Ny,:)  = harmonic_average(Prop_y(y_neg), Prop_y(y_pos));
    
elseif strcmp(type, 'Upstream')
    AvgProp_x(2:Nx,:,:)  = upstream(Prop_x(x_neg), Prop_x(x_pos), P(x_neg), P(x_pos));
    AvgProp_y(:,2:Ny,:)  = upstream(Prop_y(y_neg), Prop_y(y_pos), P(y_neg), P(y_pos));
else
    
    Disp('Error: Select a valid averaging method (Mean, Harmonic or Upstream)');
end

%--------------------------------------------------------------------------------------
Prop_xpos = reshape(AvgProp_x(1:Nx,:,:),Nt,1); Prop_xneg = reshape(AvgProp_x(2:Nx+1,:,:),Nt,1);
Prop_ypos = reshape(AvgProp_y(:,1:Ny,:),Nt,1); Prop_yneg = reshape(AvgProp_y(:,2:Ny+1,:),Nt,1);

