function [Rock] = compute_geopart_avg(Discretization, Rock, Solution, Constants)

Dx   = Discretization.Dx;
Dy   = Discretization.Dy;
Dz   = Discretization.Dz;
Ax   = Discretization.Ax;
Ay   = Discretization.Ay;
Az   = Discretization.Az;
type = Discretization.Geom_AvgType; 
%--------------------
Bc  = Constants.Bc;
%---------------------
Kx = Rock.Kx;
Ky = Rock.Ky;
%---------------------
[K_xpos K_xneg K_ypos K_yneg] = property_avg(Discretization, Solution, Bc*Ax*Kx/Dx, Bc*Ay*Ky/Dy, type);
%----------------------
Rock.K_xpos   = K_xpos;
Rock.K_xneg   = K_xneg;
Rock.K_ypos   = K_ypos;
Rock.K_yneg   = K_yneg;
end