function [Wells, Solution]= save_results(Mobility,Wells,Solution)

Qinj_ind    = Wells.Qinj_ind;
Qpro_ind    = Wells.Qpro_ind;
fro         = Mobility.fro;
frw         = Mobility.frw;

Wells.fro   = [Wells.fro, fro(Qpro_ind)];
Wells.frw   = [Wells.frw, frw(Qpro_ind)];

%--------------------------------------------------------
Solution.Ppast      = Solution.Pcurrent;
Solution.Swpast     = Solution.Swcurrent;
Solution.P          = [Solution.P,Solution.Pcurrent];
Solution.Sw         = [Solution.Sw,Solution.Swcurrent];


end