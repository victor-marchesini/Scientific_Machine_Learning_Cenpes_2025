function [sys, sysd] = StateSpaceNaive(Discretization, Accumulation, Transmisibility,Mobility, Wells)

%% Starting point: Residual equation
% Residual   = Trans*X - Acc * (X - Xpast) + q = 0; 

%% Accumulation
% We are interested in the ODE, thus we have to multiply A by dt to
% "undiscretize" in time
Acc = Accumulation.Acc*(Discretization.Dt);

%% Transmissibility
% Remember that we q is given by the Peaceman equation [q = J(P_well -
% p_grid)]. Thus we have to include the terms correspond to p_grid inside
% the transmissibility matric see "compute_source" function for reference
Trans   = Transmisibility.T - Wells.Q;

%% Sources/sinks => Control Form
% Defining u = [Wells.Pwf_pro ; Wells.Qinj]
% we should find a matrix F such that F*u = q;
Nt          = Discretization.Nt;
fro         = Mobility.fro;
frw         = Mobility.frw;
J_pro       = Wells.J_pro;
Qinj_ind    = Wells.Qinj_ind;
Qpro_ind    = Wells.Qpro_ind;
Npro        = Wells.Npro;
Ninj        = Wells.Ninj;
Nwells = Npro+Ninj;

Fo = spalloc(Nt,Nwells,Nwells);
Fw = spalloc(Nt,Nwells,Nwells);

%---------------------
% Producer wells
%---------------------
Fo(Qpro_ind, 1:Npro)    = diag(J_pro.*fro(Qpro_ind));
Fw(Qpro_ind, 1:Npro)    = diag(J_pro.*frw(Qpro_ind));

%---------------------
% Injector wells
%---------------------
Fw(Qinj_ind, Npro+1:end) =  1;

%=========================================
F = [Fo ; Fw];

% you can check if F*u == q; where u = [Wells.Pwf_pro ; Wells.Qinj]

%% State Space Form matrices A and B
% Rearranging the residual equation:
%   Acc*dot(x) = Trans*X + F*u,
%       dot(x = inv(Acc)*Trans*X  + inv(Acc)*F*u
A = Acc\Trans;
B = Acc\F;


%% Observable Matrix: C and D
% Defining the output y as [p_inj_well ; q_prod_well]
% We need to find a algebric equation of the form:
%       y = C*x + D*u
% For this, we have that the vector y can be found by:
% (1) q_prod_well are found by  the Peaceman equation q = J(p_well - p_grid)
%       In the C matrix only the term -J*p_grid is considered. J*p_well
%       will be considered on D.
% (2) p_inj_well is found by rearranging the Peaceman equation
%        pwell = inv(J)*q + p_grid. Again, we have to split the terms
%        between C and D
N_y = Ninj+2*Npro; % For each producer, 2 rates (qw + qo)

Cp = spalloc(N_y,Nt,Nwells); 
Cs = spalloc(N_y,Nt,Nwells); 
D  = spalloc(N_y,Nwells,Nwells);

%---------------------
% Producer wells => q_prod_well = [q_prod_well_o; q_prod_well_w]
%---------------------
Cp(1:Npro , Qpro_ind)           = - diag(J_pro.*fro(Qpro_ind));
Cp(Npro+1:2*Npro , Qpro_ind)    = - diag(J_pro.*frw(Qpro_ind));
D(1:Npro, 1:Npro)               = diag(J_pro.*fro(Qpro_ind));
D(Npro+1:2*Npro, 1:Npro)        = diag(J_pro.*frw(Qpro_ind));

%---------------------
% Injector wells => q_prod_well
%---------------------
% we need the Productivity index for the injectors; inserted on
% "pre_processing.m"
J_inj = Wells.J_inj;

Cp(2*Npro+1:end,Qinj_ind) = eye(Ninj);
D(2*Npro+1:end,1:Ninj)    = diag(inv(J_inj)); %How to use backslash?

%=========================================
C = [Cp , Cs];

%% State state system
sys = ss(full(A),full(B),full(C),full(D));

sysd = dss(full(Trans),full(F),full(C),full(D),full(Acc));












