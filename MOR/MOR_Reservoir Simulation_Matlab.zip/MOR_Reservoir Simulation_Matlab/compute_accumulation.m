function [Accumulation] = compute_accumulation(Discretization, Constants, Fluid, Rock, Solution)

%=============================
Vb      = Discretization.Vb;
Dt      = Discretization.Dt;
Nt      = Discretization.Nt;
Ac      = Constants.Ac;
bo      = Fluid.bo;
bw      = Fluid.bw;
dbo     = Fluid.dbo;
dbw     = Fluid.dbw;
poro    = Rock.poro;

Coeff   = Vb/(Ac*Dt);

%=============================
Sw      = Solution.Swcurrent;
So      = 1-Sw;

%================================================================================================================
Cwp     =  Coeff * ( 0 + poro*dbw ) .* Sw;  % Consider bw.*dphi, where dphi change in the porosity wrt pressure
Cop     =  Coeff * ( 0 + poro*dbo ) .* So;  % Consider bo.*dphi, where dphi change in the porosity wrt pressure
%-------------------------------------------------------------------------------------------------------------------------------------
Cws     =  Coeff * ( poro.*bw  - 0 );       % Consider Sw.*phi.*dBw.*dPc, where dPc is the change in the capillary pressure wrt pressure
Cos     = -Coeff * ( poro.*bo      );
%-------------------------------------------------------------------------------------------------------------------------------------

%=========================
d11     = spdiags(Cop,0,Nt,Nt); 
d12     = spdiags(Cos,0,Nt,Nt); 
d21     = spdiags(Cwp,0,Nt,Nt); 
d22     = spdiags(Cws,0,Nt,Nt); 
Acc     = [d11 d12; d21 d22];

%=============================
Accumulation.Acc    = Acc;
%=============================

end
