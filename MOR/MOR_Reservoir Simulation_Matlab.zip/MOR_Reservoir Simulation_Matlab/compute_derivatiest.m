function varargout=compute_derivatiest(f,x)
% Approximate the derivative of a function applying centeral difference

if min(min(x))
    delta  = 1e-3*min(min(x));
else
    delta  = 1e-3;
end
% First derivative
[fo_p,fw_p]     = f(x+delta);
[fo_n,fw_n]     = f(x-delta);
% [fo_n,fw_n]     = f(x);
dfo             = (fo_p-fo_n)./(2*delta);
dfw             = (fw_p-fw_n)./(2*delta);
varargout{1}    = dfo;
varargout{2}    = dfw;

% Second derivative 
if nargout > 2,
    [fo,fw]         = f(x);
    [fo_p,fw_p]     = f(x+2*delta);
    [fo_n,fw_n]     = f(x-2*delta);
    ddfo            = (fo_p-2*fo+fo_n)./(4*delta^2);
    ddfw            = (fw_p-2*fw+fw_n)./(4*delta^2);
    varargout{3}    = ddfo;
    varargout{4}    = ddfw;
end
end