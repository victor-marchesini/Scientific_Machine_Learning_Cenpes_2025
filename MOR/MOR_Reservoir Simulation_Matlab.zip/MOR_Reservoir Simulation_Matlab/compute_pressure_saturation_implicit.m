function [Solution] = compute_pressure_saturation_implicit(Discretization, Reduction, Equations, Solution, LinSolver_Type)

%=================================
Nt  = Discretization.Nt;
%=================================
Ts  = Equations.Left;
Bs  = Equations.Right;

%=================================
% SOLUTION SYSTEM OF EQUATION
%=================================
tol     = 1e-3;
maxiter = 10;
%------------
if strcmp(LinSolver_Type,'GMRES')
%    [Xs, normrn] = GMRES_alex(Ts,Bs,maxiter);
    [Xs] = gmres(Ts,Bs,5,tol,maxiter); % [Matlab]
%     [Xs]    = gmres(Ts,Bs); % [Matlab]

elseif strcmp(LinSolver_Type,'CG')
%    [Xs, m]      = CG_alex(Ts,Bs,Pcurrent,tol,maxiter);
    [Xs]    = pcg(Ts,Bs);  % [Matlab]

else % [Gaussian elimination]
    [Xs]    = Ts\Bs;
end

%=================================
% Assign the solution
%=================================
if strcmp(Reduction.Mode,'POD') || strcmp(Reduction.Mode,'DEIM')
    Phi     = Reduction.BasisPOD.Phi;
    X       = Phi*Xs;
    
else % [Full Model]    
    X       = Xs;
    
end

%=================================
% Update the solution
%=================================
Solution.Pcurrent   = Solution.Pcurrent + X(1:Nt);
Solution.Swcurrent  = Solution.Swcurrent + X(Nt+1:end);

Solution.Update     = max(norm(X(1:Nt))/3000,norm(X(Nt+1:end)));

end




