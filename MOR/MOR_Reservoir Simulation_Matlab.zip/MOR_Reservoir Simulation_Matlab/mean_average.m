function [x] = mean_average(x1,x2)

x = 0.5 * (x1 + x2);

return