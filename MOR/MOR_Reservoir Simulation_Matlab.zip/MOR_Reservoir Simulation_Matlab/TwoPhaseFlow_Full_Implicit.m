clearvars; close force all; clc;

[Geometry, Discretization, Fluid, Rock, Wells, Conditions, Constants] = initialize; 
Reduction.Mode                          = 'Off';
[Discretization, Wells, FullSolution]   = pre_processing(Geometry, Discretization, Rock, Wells, Conditions, Constants, Reduction);
[Rock]                                  = compute_geopart_avg(Discretization, Rock, FullSolution, Constants);

%%
%====================================
% Time loop
%====================================

h = waitbar(0,'1','Name','Running simulation...',...
            'CreateCancelBtn',...
            'setappdata(gcbf,''canceling'',1)');
setappdata(h,'canceling',0);

Discretization.n    = 1;
Discretization.time = 0;
ResidulNorm         = 1;
FullSolution.Update = 1;
iteration           = 0;
tic
while Discretization.time(end)<Discretization.Tsim
%     while ResidulNorm > 1e-2 
    while FullSolution.Update > 1e-6
        [Fluid]             = update_fluid_properties(Fluid,FullSolution);
        [Rock]              = update_rock_properties(Rock,FullSolution);
        [Mobility]          = compute_mobility(Fluid,Rock);
        [Wells]             = compute_source(Discretization, Mobility, Wells);
        [Accumulation]      = compute_accumulation(Discretization, Constants, Fluid, Rock, FullSolution);
        [Transmisibility]   = compute_transmisibility(Discretization, Rock, Mobility, FullSolution);
        [Residual]          = compute_residual(Transmisibility, Accumulation, Wells, FullSolution);
        [Jac, Jacobians]    = compute_Jacobian(Discretization, Constants, Fluid, Rock, Mobility, Wells, Accumulation, Transmisibility, FullSolution);
        [Equations]         = compute_flow_vector_implicit(Residual, Jac, Reduction);
        [FullSolution]      = compute_pressure_saturation_implicit(Discretization, Reduction, Equations, FullSolution, 'GE');
        ResidulNorm         = norm(Residual,inf);
        iteration           = iteration+1;
        
% Just in case we want to create a naive linear state space system (sys = ss(A,B,C,D))
         if size(Discretization.time,2) == 2 % iteration==10
            sys = StateSpace(Discretization, Constants, Transmisibility, Accumulation, Wells, Jacobians, Fluid, Rock, Mobility, FullSolution);
            q=0;

%             A_ss = Accumulation\Transmisibility;
%             B_ss = Accumulation\SelectionMContrrol;
%             C_ss = SelectionMOutputs; 
%             D_ss = zeros(size(C_ss(1), B_ss(2)));
         end
 
    end
    FullSolution.Update     = 1;
    ResidulNorm             = 1;
    iteration               = 0;
    [Wells, FullSolution]   = save_results(Mobility,Wells,FullSolution);
    [FullSolution]          = NonlinFuncEval(Discretization, Transmisibility, Accumulation, FullSolution); % Evaluates nonlinear functions at the resutls to be used in DEIM
    [Discretization]        = compute_time(Discretization);


    % Check for Cancel button press
    if getappdata(h,'canceling')
        break
    end
    % Report current estimate in the waitbar's message field
    waitbar(Discretization.time(end)/Discretization.Tsim,h,sprintf('%2.1f',100*Discretization.time(end)/Discretization.Tsim));

  
end   
FullSys_t = toc

delete(h);       
save FullSolution.mat FullSolution
% save FullSys_t FullSys_t
visualize_results(Discretization,Rock,Wells,Reduction,FullSolution);




