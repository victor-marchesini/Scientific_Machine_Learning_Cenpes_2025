function [C, D] = compute_output_matrix(Discretization,Mobility, Wells)

Nt          = Discretization.Nt;
J_pro       = Wells.J_pro;
Qinj_ind    = Wells.Qinj_ind;
Qpro_ind    = Wells.Qpro_ind;
Npro        = Wells.Npro;
Ninj        = Wells.Ninj;
Nwells      = Npro+Ninj;

mob_o	= Mobility.fro;
mob_w 	= Mobility.frw;

%% Fractional flow - only for producers wells
mob_total	= mob_o + mob_w;
Fr_o        = mob_o./mob_total;
Fr_w        = mob_w./mob_total;

%% Observables Matrix: C and D
% Defining the output y as [p_inj_well ; q_prod_well]
% We need to find a algebric equation of the form:
%       y = C*x + D*u
% For this, we have that the vector y can be found by:
% (1) q_prod_well are found by  the Peaceman equation q = J(p_well - p_grid)
%       In the C matrix only the term -J*p_grid is considered. J*p_well
%       will be considered on D.
% (2) p_inj_well is found by rearranging the Peaceman equation
%        pwell = inv(J)*q + p_grid. Again, we have to split the terms
%        between C and D
Cs = spalloc(2*Npro+Ninj,Nt,0); 

Cprod_o = spalloc(Npro,Nt,Npro);
Cprod_w = spalloc(Npro,Nt,Npro);
Dprod_o = spalloc(Npro,Npro,Npro);
Dprod_w = spalloc(Npro,Npro,Npro); 

Cinj = spalloc(Ninj,Nt,Ninj);
Dinj = spalloc(Ninj,Ninj,Ninj);
%---------------------
% Producer wells
%---------------------
Cprod_o(:,Qpro_ind)	= - diag(J_pro.*Fr_o(Qpro_ind).*mob_o(Qpro_ind));
Cprod_w(:,Qpro_ind)	= - diag(J_pro.*Fr_w(Qpro_ind).*mob_w(Qpro_ind));

Dprod_o(:,:) = diag(J_pro.*Fr_o(Qpro_ind).*mob_o(Qpro_ind));
Dprod_w(:,:) = diag(J_pro.*Fr_w(Qpro_ind).*mob_w(Qpro_ind));

%---------------------
% Injector wells => q_prod_well
%---------------------
% we need the Productivity index for the injectors; inserted on
% "pre_processing.m"
J_inj = Wells.J_inj;

Cinj(:,Qinj_ind)	= eye(Ninj);
Dinj(:,:)       	= diag(inv(J_inj.*Fr_o(Qinj_ind).*mob_o(Qinj_ind))); % Should I use backslah?

%=========================================
% C = [Cprod_o; Cprod_w ; Cinj];
% C = [C  Cs];
C = [Cprod_o' Cprod_w' Cinj'; Cs']';

D = [spalloc(Npro,Ninj,0) Dprod_o; spalloc(Npro,Ninj,0) Dprod_w ; Dinj  spalloc(Ninj,Npro,0) ];
% =========================================