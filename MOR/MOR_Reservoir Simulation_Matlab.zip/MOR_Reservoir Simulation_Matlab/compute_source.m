function Wells = compute_source(Discretization, Mobility, Wells)

Nt          = Discretization.Nt;
fro         = Mobility.fro;
frw         = Mobility.frw;
Qinj        = Wells.Qinj;
Pwf_pro     = Wells.Pwf_pro;
J_pro       = Wells.J_pro;
Qinj_ind    = Wells.Qinj_ind;
Qpro_ind    = Wells.Qpro_ind;
Npro        = Wells.Npro;

%================================
Qo      = spalloc(Nt,1,Npro);
Qw      = spalloc(Nt,1,Npro);
qo      = spalloc(Nt,1,Npro);
qw      = spalloc(Nt,1,Npro);

%---------------------
% Producer wells
%---------------------
Qo(Qpro_ind)    =  J_pro.*fro(Qpro_ind) ;
Qw(Qpro_ind)    =  J_pro.*frw(Qpro_ind) ;

qo(Qpro_ind)    =  Pwf_pro.*J_pro.*fro(Qpro_ind);
qw(Qpro_ind)    =  Pwf_pro.*J_pro.*frw(Qpro_ind);

%---------------------
% Injector wells
%---------------------
qw(Qinj_ind)    = qw(Qinj_ind) + Qinj;

%=========================
Q   = [diag(Qo), spalloc(Nt,Nt,0); diag(Qw), spalloc(Nt,Nt,0)]; 
q   = [qo; qw];

%=========================================
Wells.Q     = Q;
Wells.q     = q;

end