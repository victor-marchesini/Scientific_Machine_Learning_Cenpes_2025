function sys = StateSpace(Discretization, Constants, Transmisibility, Accumulation, Wells,Jacobians, Fluid, Rock, Mobility, Solution)
Acc     = Accumulation.Acc;

T	= Transmisibility.T;
dT 	= Jacobians.dT;
Q	= Wells.Q;
q 	= Wells.q;
dQ	= Jacobians.dQ;

P	= Solution.Pcurrent;
Sw 	= Solution.Swcurrent;
X 	= [P; Sw];

%% Starting point: Residual equation
% R  = Trans*X - Acc * (X - Xpast) + q = 0; 
% g  = Trans*X - Acc * X_dot + q = 0; 

%% System Matrix: A
dTX             = T + dT;	% Transmissibility is equal to the original code
Acc             = Acc*(Discretization.Dt);     % We need to undiscretize it
dg_dx_dot       = -(Acc);

x_dot_current   = (T + Q)*X + q;     % Current value of f(x,u)
[~, dAcc_x_dot] = compute_acc_derivative_ss(Discretization, Constants, Fluid, Rock, Solution, x_dot_current);
dg_dx           = dTX - dAcc_x_dot + (Q + dQ);

A               = dg_dx_dot\dg_dx;

%% Input Matrix: B
% u = [Pwf_pro ; Qinj]
L       = compute_location_matrix(Discretization,Mobility, Wells);
dg_du	= L;

B       = dg_dx_dot\dg_du;

%% Output Matrix
% y = [p_inj_well ; q_prod_well]
[C_x, D_x]  = compute_output_matrix(Discretization,Mobility, Wells);

C           = compute_linearized_C(Discretization,Mobility, Wells, C_x, Solution);

%% Direct Throughput Matrix: D
D = D_x;

%% State Space systems
sys = ss(full(A),full(B),full(C),full(D));


