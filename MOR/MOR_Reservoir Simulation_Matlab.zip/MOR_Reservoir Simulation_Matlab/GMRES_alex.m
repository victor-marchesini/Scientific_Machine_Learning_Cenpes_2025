function [x , normrn] = GMRES_alex(A,b,maxiter)

Q = [];
H = 0;
m = length(A);
normb = norm(b);
normrn=normb;
Q(:,1) = b / normb;
 
for n = 1:maxiter
    % Arnoldi step calculations (Algorithm 33.1 for Trefethen and Bau)
    v = A*Q(:,n);
    for j = 1:n
        H(j,n) = Q(:,j)'* v;
        v = v  - H(j,n)*Q(:,j);
    end
    Hn = H(1:n,1:n);
    H(n+1,n) = norm(v);
    if H(n+1,n) == 0, break, end    % breakdown so stop
    Q(:,n+1) = v / H(n+1,n);
    e1 = [1;zeros(n,1)];
    y = H \ (normb*e1);  % This can be done much more quickly
                         % using Givens rotations.
                         % For simplicity we just use Matlab's \
    normrn = [normrn,norm(H*y-normb*e1)];   % remember residual norm                         
end
x = Q(:,1:n)*y;


return
