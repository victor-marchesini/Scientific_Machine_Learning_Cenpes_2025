function [Transmisibility] = compute_transmisibility(Discretization, Rock, Mobility, Solution)

%============================================
% Getting the parameters from data structures
%============================================
Nx      = Discretization.Nx;
Ny      = Discretization.Ny;
Nt      = Discretization.Nt;
type    = Discretization.Fluid_AvgType;
K_xpos  = Rock.K_xpos;
K_xneg  = Rock.K_xneg;
K_ypos  = Rock.K_ypos;
K_yneg  = Rock.K_yneg;

%=====================================================================================================
fro     = Mobility.fro;
frw     = Mobility.frw;

%=====================================================================================================
[fro_xpos fro_xneg fro_ypos fro_yneg]   = property_avg(Discretization,Solution, fro, fro, type);
[frw_xpos frw_xneg frw_ypos frw_yneg]   = property_avg(Discretization,Solution, frw, frw, type);
%=====================================================================================================

% Compute components for Oil
TE_o    = K_xpos.*fro_xpos;
TW_o    = K_xneg.*fro_xneg;
TN_o    = K_ypos.*fro_ypos;
TS_o    = K_yneg.*fro_yneg;

% Compute components for Water
TE_w    = K_xpos.*frw_xpos;
TW_w    = K_xneg.*frw_xneg;
TN_w    = K_ypos.*frw_ypos;
TS_w    = K_yneg.*frw_yneg;

% Center
TC_o    = - ( TN_o + TS_o + TE_o + TW_o );
TC_w    = - ( TN_w + TS_w + TE_w + TW_w );


%=================================
T11     = spdiags([TS_o TW_o TC_o TE_o TN_o],[-Nx -1 0 1 Nx],Nt,Nt);
T12     = spalloc(Nt,Nt,0);
T21     = spdiags([TS_w TW_w TC_w TE_w TN_w],[-Nx -1 0 1 Nx],Nt,Nt);
T22     = spalloc(Nt,Nt,0);
T       = [T11 T12; T21  T22];

%=================================
% Filling out the data structures
%=================================
Transmisibility.TW_o = TW_o;
Transmisibility.TE_o = TE_o;
Transmisibility.TN_o = TN_o;
Transmisibility.TS_o = TS_o;
Transmisibility.TC_o = TC_o;
%----------------------------
Transmisibility.TW_w = TW_w;
Transmisibility.TE_w = TE_w;
Transmisibility.TN_w = TN_w;
Transmisibility.TS_w = TS_w;
Transmisibility.TC_w = TC_w;
%--------------------------------
Transmisibility.T    = T;


end