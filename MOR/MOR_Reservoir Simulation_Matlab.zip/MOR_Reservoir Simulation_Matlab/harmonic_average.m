function y = harmonic_average(x1,x2)
    y   = 1./(1./x1+1./x2);
end