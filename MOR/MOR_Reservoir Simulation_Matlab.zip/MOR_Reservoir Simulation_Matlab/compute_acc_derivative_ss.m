function [Accumulation, dAcc_ss] = compute_acc_derivative_ss(Discretization, Constants, Fluid, Rock, Solution, x_dot)

%=============================
Vb      = Discretization.Vb;
% Dt      = Discretization.Dt;
Nt      = Discretization.Nt;
Ac      = Constants.Ac;
dbo     = Fluid.dbo(:);
dbw     = Fluid.dbw(:);
ddbo    = Fluid.ddbo(:);
ddbw    = Fluid.ddbw(:);
poro    = Rock.poro;
Coeff   = Vb/(Ac);       % Coeff   = Vb/(Ac*Dt);

%=============================
p_dot = x_dot(1:Nt);
s_dot = x_dot(Nt+1:end);

Sw      = Solution.Swcurrent;
So      = 1-Sw;

%====================================================================================================================
% Cwp     =  Coeff * ( 0 + poro*dbw ) .* Sw;  % Consider bw.*dphi, where dphi change in the porosity wrt pressure
% Cop     =  Coeff * ( 0 + poro*dbo ) .* So;  % Consider bo.*dphi, where dphi change in the porosity wrt pressure
%--------------------------------------------
dCwpdP  =  Coeff * ( 0 + poro*ddbw ).*Sw; 
dCopdP  =  Coeff * ( 0 + poro*ddbo ).*So; 
dCwpdSw =  Coeff * ( 0 + poro*dbw ); 
dCopdSw = -Coeff * ( 0 + poro*dbo ); 

%---------------------------------------------------------------------------------------------------------------------------------------
% Cww     =  Coeff * ( poro.*bw  - 0 );    % Consider Sw.*phi.*dBw.*dPc, where dPc is the change in the capillary pressure wrt pressure
% Cow     = -Coeff * ( poro.*bo      );
%-------------------------------------------
dCwsdP  =  Coeff * ( poro.*dbw - 0 ); 
dCosdP  = -Coeff * ( poro.*dbo     );
dCwsdSw =  spalloc(Nt,1,0); 
dCosdSw =  spalloc(Nt,1,0);

%======================================================
dCop   = dCopdP .* p_dot + dCosdP .* s_dot;
dCos   = dCopdSw.* p_dot + dCosdSw.* s_dot;
dCwp   = dCwpdP .* p_dot + dCwsdP .* s_dot;
dCws   = dCwpdSw.* p_dot + dCwsdSw.* s_dot;

%=========================
d11         = spdiags(dCop,0,Nt,Nt); 
d12         = spdiags(dCos,0,Nt,Nt); 
d21         = spdiags(dCwp,0,Nt,Nt); 
d22         = spdiags(dCws,0,Nt,Nt); 
dAcc_ss     = [d11 d12; d21 d22];

%=============================
Accumulation.dAcc_ss   = dAcc_ss;
%=============================


end