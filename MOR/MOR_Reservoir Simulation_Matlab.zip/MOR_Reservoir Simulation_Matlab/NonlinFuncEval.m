function  [Solution] = NonlinFuncEval(Discretization, Transmisibility, Accumulation, Solution)

n           = Discretization.n;
T           = Transmisibility.T;
Acc         = Accumulation.Acc;
P           = Solution.Pcurrent;
Ppast       = Solution.Ppast;
Sw          = Solution.Swcurrent;
Swpast      = Solution.Swpast;
%===================================
X       = [P;Sw];
Xpast   = [Ppast;Swpast];
Tx  = T*X;
Ax  = Acc*(X-Xpast);
%====================================
if n == 1
    Solution.Tx     = [Tx];
    Solution.Ax     = [Ax];
else
    Solution.Tx     = [Solution.Tx, Tx];
    Solution.Ax     = [Solution.Ax, Ax];
end
end