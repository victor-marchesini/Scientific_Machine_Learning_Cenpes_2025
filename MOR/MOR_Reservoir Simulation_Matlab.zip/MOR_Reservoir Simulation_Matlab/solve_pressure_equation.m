function [Equations,Solution] = solve_pressure_equation(Piterate, Solution, Geometry, Discretization, Properties, Wells, Conditions, Constants)

Solution.Piterate = Piterate;

[Equations] = compute_components_transmisibility(Geometry,Discretization,Properties,Wells,Conditions,Constants,Solution);

[Equations] = compute_transmisibility(Discretization,Conditions,Equations);

[Equations] = compute_flow_vector(Discretization,Properties,Wells,Conditions,Equations,Solution); 

[Solution,P] = compute_pressure(Discretization, Conditions, Equations, Solution);


%==================================
% Saving the solution
%==================================
Solution.P = [Solution.P,P];
Solution.Pcurrent = P;
%==================================


return