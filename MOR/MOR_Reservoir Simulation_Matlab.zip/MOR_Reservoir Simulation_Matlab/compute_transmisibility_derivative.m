function [Transmisibility] = compute_transmisibility_derivative(Discretization, Rock, Mobility, Solution, Transmisibility)

%=====================================================================================================
dfrodP  = Mobility.dfrodP;
dfrwdP  = Mobility.dfrwdP;
dfrodSw = Mobility.dfrodSw;
dfrwdSw = Mobility.dfrwdSw;

%=================================
T11     = compute_Tij_derivative(Discretization, Rock, Solution, dfrodP);
T12     = compute_Tij_derivative(Discretization, Rock, Solution, dfrodSw);
T21     = compute_Tij_derivative(Discretization, Rock, Solution, dfrwdP);
T22     = compute_Tij_derivative(Discretization, Rock, Solution, dfrwdSw);
dT      = [T11 T12; T21  T22];

%=================================
% Filling out the data structures
%=================================
Transmisibility.dT    = dT;

end

function dTij = compute_Tij_derivative(Discretization, Rock, Solution, dprop)

Nx      = Discretization.Nx;
Ny      = Discretization.Ny;
Nt      = Discretization.Nt;
x_neg   = Discretization.x_neg;
x_pos   = Discretization.x_pos;
y_neg   = Discretization.y_neg;
y_pos   = Discretization.y_pos;
z_neg   = Discretization.z_neg;
z_pos   = Discretization.z_pos;

K_xpos  = Rock.K_xpos;
K_xneg  = Rock.K_xneg;
K_ypos  = Rock.K_ypos;
K_yneg  = Rock.K_yneg;



%============================================================================================================
[dprop_xpos dprop_xneg]       = component_derivative(Solution, dprop, x_pos, x_neg);
[dprop_ypos dprop_yneg]       = component_derivative(Solution, dprop, y_pos, y_neg);


%============================================================================================================
dTE    = K_xpos.*dprop_xpos;               
dTW    = K_xneg.*dprop_xneg;               
dTN    = K_ypos.*dprop_ypos;            
dTS    = K_yneg.*dprop_yneg;

% Center
dTC    = - ( dTN + dTS + dTE + dTW );

%==========================================================================
dTij    = spdiags([dTS dTW dTC dTE dTN],[-Nx -1 0 1 Nx],Nt,Nt);
end

function [dpos,dneg] = upstream_derivative(Ppos,Pneg)

I = find(Pneg>Ppos);

[m n k] = size(Ppos);
dneg = zeros(m,n,k); 
dpos = ones(m,n,k);
dneg(I)=1;
dpos(I)=0;

end

function [dprop_pos dprop_neg] = component_derivative(Solution,dprop,pos,neg) 

P           = Solution.Pcurrent;
Nt          = length(P);
Ppos        = P(pos);
Pneg        = P(neg);
dprop_pos   = zeros(Nt,1);  
dprop_neg   = zeros(Nt,1);

%-------------------------------------------
[dpos,dneg] = upstream_derivative(Ppos,Pneg);

%-------------------------------------------
dP              = Ppos - Pneg;
dprop_pos(pos)  =   dprop(pos).*dP.*dpos;
dprop_neg(neg)  = - dprop(neg).*dP.*dneg;


dprop_pos       = dprop_pos(:);
dprop_neg       = dprop_neg(:);


end


