function [Discretization, Wells, Solution] = pre_processing(Geometry, Discretization, Rock, Wells, Conditions, Constants, Reduction)


%=================================
% Getting the parameters from data structures
%=================================
Lx = Geometry.Lx;
Ly = Geometry.Ly;
Lz = Geometry.Lz;
%-----------------------
Nx = Discretization.Nx;
Ny = Discretization.Ny;
Nz = Discretization.Nz;
Nt = Discretization.Nt;
%---------------------------------
rw          = Wells.rw;
Skin        = Wells.Skin;
Qpro_ind    = Wells.Qpro_ind;
Qinj_ind    = Wells.Qinj_ind;
%----------------------------------
Pi      = Conditions.Initial.Pi;
Swi     = Conditions.Initial.Swi;

%-----------------------------------
Bc      = Constants.Bc;
%====================================
Dx      = Lx/Nx;   % [ft]
Dy      = Ly/Ny;   % [ft]
Dz      = Lz/Nz;   % [ft]  
Ax      = Dy*Dz;
Ay      = Dx*Dz;
Az      = Dx*Dy;
Vb      = Dx*Dy*Dz; % [ft3]

kM      = reshape(1:Nt,Nx,Ny,Nz);
x_neg   = kM(1:Nx-1,:,:);
x_pos   = kM(2:Nx,:,:);
y_neg   = kM(:,1:Ny-1,:);
y_pos   = kM(:,2:Ny,:);
z_neg   = kM(:,:,1:Nz-1);
z_pos   = kM(:,:,2:Nz);
%-----------------
P       = Pi*ones(Nt,1);  % [psi]
Sw      = Swi*ones(Nt,1); % [-]
%-----------------
Npro    = length(Qpro_ind); % Number of producer wells
Ninj    = length(Qinj_ind); % Number of producer wells

%-----------------
Kx_pro  = Rock.Kx(Qpro_ind);
Ky_pro  = Rock.Ky(Qpro_ind);

Kx_inj  = Rock.Kx(Qinj_ind);
Ky_inj  = Rock.Ky(Qinj_ind);

%-----------------
J_pro   = compute_productivity_index(Kx_pro,Ky_pro,Dx,Dy,rw,Skin,Dz,Bc); % [BPD/psi]
J_inj  = compute_productivity_index(Kx_inj,Ky_inj,Dx,Dy,rw,Skin,Dz,Bc); % [BPD/psi]
%=================================


%=================================
% Filling out the data structures
%=================================
Discretization.Dx       = Dx;
Discretization.Dy       = Dy;
Discretization.Dz       = Dz;
Discretization.Ax       = Ax;
Discretization.Ay       = Ay;
Discretization.Az       = Az;
Discretization.Vb       = Vb;
Discretization.x_neg    = x_neg;
Discretization.x_pos    = x_pos;
Discretization.y_neg    = y_neg;
Discretization.y_pos    = y_pos;
Discretization.z_neg    = z_neg;
Discretization.z_pos    = z_pos;
Discretization.n        = 0;
Discretization.time(1)  = 0;
Discretization.Fluid_AvgType    = 'Upstream';
Discretization.Geom_AvgType     = 'Harmonic';
%==============================
Wells.Npro = Npro;
Wells.Ninj = Ninj;
%-----------------
Wells.J_pro = J_pro;
Wells.J_inj = J_inj;
%-------------------
Wells.fro   = zeros(Npro,1);
Wells.frw   = zeros(Npro,1);
%================================
Solution.P         = P;
Solution.Ppast     = P;
Solution.Pcurrent  = P;
%-----------------
Solution.Sw        = Sw;
Solution.Swpast    = Sw;
Solution.Swcurrent = Sw;
%=================================
if strcmp(Reduction.Mode,'POD') || strcmp(Reduction.Mode,'DEIM')
    Phi_P   = Reduction.BasisPOD.Phi_P;
    Phi_Sw  = Reduction.BasisPOD.Phi_Sw;
    
    Solution.rPcurrent  = Phi_P'*P;
    Solution.rSwcurrent = Phi_Sw'*Sw;
end
 
 return