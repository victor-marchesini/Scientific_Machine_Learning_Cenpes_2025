function [Reduction] = compute_POD_basis(Reduction, Solution)

P       = Solution.P;
Sw      = Solution.Sw;
nrP     = Reduction.nrP;
nrSw    = Reduction.nrSw;

[m n]   = size(P);
Pavg    = repmat(mean(P,2),1, n);
Swavg   = repmat(mean(Sw,2),1, n);

% Compute POD basis from snapshots
% [V S W]     = svd(P - Pavg, 'econ');
[V S W]     = svd(P , 'econ');
SingP       = diag(S);
Phi_P       = V(:,1:nrP);
% [V S W]     = svd(Sw - Swavg, 'econ');
[V S W]     = svd(Sw , 'econ');
SingSw      = diag(S);
Phi_Sw      = V(:,1:nrSw);
Phi         = blkdiag(Phi_P,Phi_Sw);


Reduction.EnergyP           = 100*sum(SingP(1:nrP)) / sum(SingP);
Reduction.EnergySw          = 100*sum(SingSw(1:nrSw)) / sum(SingSw);
Reduction.BasisPOD.Phi_P    = Phi_P;
Reduction.BasisPOD.Phi_Sw   = Phi_Sw;
Reduction.BasisPOD.Phi      = Phi;
Reduction.BasisPOD.SingP    = SingP;
Reduction.BasisPOD.SingSw   = SingSw;


% figure(); axes('YScale', 'log');
% plot(SingP, '-o');
% plot(SingSw, 'r*');
% legend('Po','Sw','Location','Best');
% title(['Singular values (# snapshots=', num2str(n), ')']);

end