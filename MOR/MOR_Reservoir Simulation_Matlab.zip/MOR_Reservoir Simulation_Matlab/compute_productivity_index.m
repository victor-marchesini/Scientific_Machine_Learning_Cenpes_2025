function [J] = compute_productivity_index(Kx,Ky,Dx,Dy,rw,Skin,h,Bc)

    Kh = sqrt(Kx.*Ky); 
    req =  0.28*sqrt( sqrt(Ky./Kx)*Dx^2 + sqrt(Kx./Ky)*Dy^2);   
    req = req ./((Ky./Kx).^(1/4) + (Kx./Ky).^(1/4)) ; % [ft]
    J = 2*pi*Bc*Kh*h;   
    J = J./ ( log(req/rw) + Skin ); % [STB/day/psi]
    
return