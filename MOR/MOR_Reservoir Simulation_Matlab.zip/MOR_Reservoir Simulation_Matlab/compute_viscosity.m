function varargout = compute_viscosity(Properties,P)

[Uo,Uw]         = compute_mu(Properties,P);
varargout{1}    = Uo;
varargout{2}    = Uw;

if nargout > 2,
    [dUo, dUw]      = compute_derivatiest(@(P) compute_mu(Properties,P),P);
    varargout{3}    = dUo;
    varargout{4}    = dUw;
end

end


function [Uo,Uw] = compute_mu(Properties,P)

Uw_table    = Properties.Uw_table;
Uw          = property_interp(Uw_table(:,1),Uw_table(:,2),P); % [cp]

%============================
Uo_table    = Properties.Uo_table;
Uo          = property_interp(Uo_table(:,1),Uo_table(:,2),P); % [cp]

%============================
end