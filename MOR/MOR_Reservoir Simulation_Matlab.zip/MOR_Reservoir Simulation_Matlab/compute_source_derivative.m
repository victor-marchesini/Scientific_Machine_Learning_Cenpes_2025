function Wells = compute_source_derivative(Discretization, Mobility, Wells, Solution)

Nt          = Discretization.Nt;
Pwf_pro     = Wells.Pwf_pro;
J_pro       = Wells.J_pro;
Qinj_ind    = Wells.Qinj_ind;
Qpro_ind    = Wells.Qpro_ind;
Npro        = Wells.Npro;

dfrodP      = Mobility.dfrodP;
dfrwdP      = Mobility.dfrwdP;
dfrodSw     = Mobility.dfrodSw;
dfrwdSw     = Mobility.dfrwdSw;

P           = Solution.Pcurrent;

dqodP       = spalloc(Nt,1,Npro);
dqwdP       = spalloc(Nt,1,Npro);
dqodSw      = spalloc(Nt,1,Npro);
dqwdSw      = spalloc(Nt,1,Npro);

Coeff       = (P(Qpro_ind)-Pwf_pro).*J_pro;
%================================
%---------------------
% Producer wells
%---------------------
dqodP(Qpro_ind)  =  Coeff.*dfrodP(Qpro_ind);
dqwdP(Qpro_ind)  =  Coeff.*dfrwdP(Qpro_ind);
dqodSw(Qpro_ind) =  Coeff.*dfrodSw(Qpro_ind);
dqwdSw(Qpro_ind) =  Coeff.*dfrwdSw(Qpro_ind);

%---------------------
% Injector wells
%---------------------
% dqwdP(Qinj_ind)    = 0;
% dqwdSw(Qinj_ind)    = 0;

%=========================================================
dQ   = [diag(dqodP) diag(dqodSw); diag(dqwdP) diag(dqwdSw)];

%=========================================
Wells.dQ     =  dQ ;


end