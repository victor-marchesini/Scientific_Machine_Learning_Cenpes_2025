function [Equations] = compute_flow_vector_implicit(Residual,Jac,Reduction)

sizesJR = [size(Jac,1), size(Residual,1)];
%====================================
if strcmp(Reduction.Mode,'POD')
    Phi = Reduction.BasisPOD.Phi;
    R   = Phi'*Residual;
    J   = Phi'*Jac*Phi;
    sizesJR_r = [size(J,1), size(R,1)];
    
   
elseif strcmp(Reduction.Mode,'DEIM')
    Phi     = Reduction.BasisPOD.Phi;
    rP      = Solution.rPcurrent;
    rSw     = Solution.rSwcurrent;
    Phi_Tx  = Reduction.BasisDEIM.Phi_Tx;
    U_Tx    = Reduction.BasisDEIM.U_Tx;
    Phi_Ax  = Reduction.BasisDEIM.Phi_Ax;
    U_Ax    = Reduction.BasisDEIM.U_Ax;
    A       = Phi'*U_Ax*Acc(Phi_Ax,:)*Phi;
    T       = Phi'*U_Tx*Trans(Phi_Tx,:)*Phi;
    X       = [rP; rSw];
    q       = Phi'*qs;
    
else % [Full Model]
    R = Residual;
    J = Jac;
   sizesJR = [size(J,1), size(R,1)];
end


%====================================
Equations.Right = - R;
Equations.Left  = J;

Equations.JacSizes = [sizesJR];
% Equations.JacSizes = [sizesJR ;
%                       sizesJR_r];
end

