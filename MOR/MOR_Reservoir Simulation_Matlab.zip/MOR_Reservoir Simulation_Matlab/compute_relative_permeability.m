function varargout = compute_relative_permeability(Properties,Sw)

[kro,krw]       = compute_relperm(Properties,Sw);
varargout{1}    = kro;
varargout{2}    = krw;


if nargout > 2,
    [dkro, dkrw]    = compute_derivatiest(@(Sw) compute_relperm(Properties,Sw),Sw);
    varargout{3}    = dkro;
    varargout{4}    = dkrw;
end

end

function [kro, krw] = compute_relperm(Properties,Sw)
So = 1-Sw;
%============================
krw_table   = Properties.krw_table;
krw         = property_interp(krw_table(:,1),krw_table(:,2),Sw);

%-----------------------------------------------------------------
kro_table   = Properties.kro_table;
kro         = property_interp(kro_table(:,1),kro_table(:,2),So);

%==============================
end
