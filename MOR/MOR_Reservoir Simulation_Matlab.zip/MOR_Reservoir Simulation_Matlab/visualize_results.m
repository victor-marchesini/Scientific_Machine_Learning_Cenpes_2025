function visualize_results(Discretization,Rock,Wells,Reduction,Solution)
close all;                               
%=================================
% Getting the parameters from data structures
%=================================
Nx      = Discretization.Nx;
Ny      = Discretization.Ny;
Nz      = Discretization.Nz;
n       = Discretization.n;
time    = Discretization.time;
%-----------------
Kx      = Rock.Kx;
Ky      = Rock.Ky;
%-----------------
Npro    = Wells.Npro;
Ninj    = Wells.Ninj;
%-----------------
Qinj    = Wells.Qinj;
Pwf_pro = Wells.Pwf_pro;
J_pro   = Wells.J_pro;
Qinj_ind = Wells.Qinj_ind;
Qpro_ind = Wells.Qpro_ind;
fro     = Wells.fro;
frw     = Wells.frw;
%-----------------
P       = Solution.P;
Sw      = Solution.Sw;
%-----------------

time_sel = [100,200,300,400,500]; % [days]

%=================================
% 1) FIELD PRESSURE
%=================================
figure;
xlabel('Gridblock in X'); ylabel('Gridblock in Y')
colorbar('Location','EastOutside');
axis([1 Nx 1 Ny]);

% Create the animation of changing the pressure
if strcmp(Reduction.Mode, 'Off')
    str = sprintf('Pressure_FullSolution.avi');
else
    str = sprintf('Pressure_%sSolution.avi',Reduction.Mode);
end
% VidObj=VideoWriter(str);
% open(VidObj);
% set(gca,'nextplot','replacechildren');
for k=1:n
    CurrentPressure=reshape(P(:,k),Nx,Ny,Nz);
    pcolor(CurrentPressure(:,:,1)); 
    title(sprintf('Oil Pressure\n%2.1f days',time(k)));
    drawnow;
%     currFrame=getframe(gcf);
%     writeVideo(VidObj,currFrame);
end
% close(VidObj);
%-----------------------------------------------
% load('RESULTS_ECLIPSE_PRESS','ECLIPSE_PRESS');
%-----------------------------------------------

%=================================
% 2) FIELD SATURATION
%=================================
figure;
xlabel('Gridblock in X'); ylabel('Gridblock in Y');
colorbar('Location','EastOutside');
axis([1 Nx 1 Ny]);

% Create the animation of changing the pressure
if strcmp(Reduction.Mode, 'Off')
    str = sprintf('Sw_FullSolution.avi');
else
    str = sprintf('Sw_%sSolution.avi',Reduction.Mode);
end
% VidObj=VideoWriter(str);
% open(VidObj);
% set(gca,'nextplot','replacechildren');
for k=1:n
    CurrentSw=reshape(Sw(:,k),Nx,Ny,Nz);
    pcolor(CurrentSw(:,:,1));
    title(sprintf('Water Saturation\n%2.1f days',time(k)));
    drawnow;
%     currFrame=getframe(gcf);
%     writeVideo(VidObj,currFrame);
end
% close(VidObj);
%---------------------------------------------
% load('RESULTS_ECLIPSE_SATW','ECLIPSE_SATW');
%---------------------------------------------

%======================================
% 3) BOTTOMHOLE PRESSURE AND FLOW RATES
%======================================
for i=2:n
    P_pro           = P(Qpro_ind,i);
    Qprod_o(:,i)    = ( P_pro - Pwf_pro ).*( J_pro .* fro(:,i));
    Qprod_w(:,i)    = ( P_pro - Pwf_pro ).*( J_pro .* frw(:,i));
end
%------------------
Qinj_w(Qinj_ind,1:n) = Qinj.*ones(Ninj,n); % [STB/day]
%----------------
% load('RESULTS_ECLIPSE_WELL','ECLIPSE_WELL')
%----------------
figure
title('Oil production rate')
plot(time(1:n),Qprod_o)
hold on
%plot(ECLIPSE_WELL(:,1),ECLIPSE_WELL(:,2:5),'-.')
legend('PROD 1','PROD 2','PROD 3','PROD 4','Location','Best')
xlabel('Time (days)')
ylabel('Oil production rate (STB/day)')
axis([0,max(time),0,max(Qinj)])
%----------------
figure
title('Water production rate')
plot(time(1:n),Qprod_w)
hold on
%plot(ECLIPSE_WELL(:,1),ECLIPSE_WELL(:,6:9),'-.')
legend('PROD 1','PROD 2','PROD 3','PROD 4','Location','Best')
xlabel('Time (days)')
ylabel('Water production rate (STB/day)')
axis([0,max(time),0,max(Qinj)])

%=================================
% PERMEABILITY FIELD
%=================================
figure
imagesc(Kx); colorbar;
xlabel('Gridblock in X'); ylabel('Gridblock in Y');
title('Permeability')
axis([1 Nx 1 Ny]);

%==========================================
% Model Reduction
%==========================================
% POD
if strcmp(Reduction.Mode,'POD')
    SingP   = Reduction.BasisPOD.SingP;
    SingSw  = Reduction.BasisPOD.SingSw;
    
    figure(); axes('YScale', 'log');
    plot(SingP, '-o');
    legend('Po','Location','Best');

    figure(); axes('YScale', 'log');
    plot(SingSw, 'r*');
    legend('Sw','Location','Best');
    title(['Singular values (# snapshots=', num2str(n), ')']);
end

% DEIM
if strcmp(Reduction.Mode,'DEIM')
    SingTX = Reduction.BasisDEIM.SingTX;
    SingAx = Reduction.BasisDEIM.SingAx;
    figure(); axes('YScale', 'log');
    plot(SingTX, '*');
    plot(SingAx, 'ro');
    legend('Tx', 'Ax');
    title(['Singular values (# snapshots=', num2str(n), ')']);
end

return