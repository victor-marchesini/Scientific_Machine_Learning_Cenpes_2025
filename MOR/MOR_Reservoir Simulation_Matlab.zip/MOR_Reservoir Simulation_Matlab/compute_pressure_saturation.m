function [Solution] = compute_pressure_saturation(Equations, Reduction, Solution, LinSolver_Type)

%=================================
% Getting the parameters from data structures
%=================================
Ts      = Equations.Left;
Bs      = Equations.Right;

%=================================
% SOLUTION SYSTEM OF EQUATION
%=================================
tol     = 1e-8;
maxiter = 100;
%------------
if strcmp(LinSolver_Type,'GMRES')
%    [Xs, normrn] = GMRES_alex(Ts,Bs,maxiter);
    [Xs] = gmres(Ts,Bs,5,tol,maxiter); % [Matlab]
%     [Xs]    = gmres(Ts,Bs); % [Matlab]

elseif strcmp(LinSolver_Type,'CG')
%    [Xs, m]      = CG_alex(Ts,Bs,Pcurrent,tol,maxiter);
    [Xs]    = pcg(Ts,Bs);  % [Matlab]

else % [Gaussian elimination]
    [Xs]    = Ts\Bs;
end

%=================================
% Saving the solution
%=================================

if strcmp(Reduction.Mode,'POD') || strcmp(Reduction.Mode,'DEIM')
    nrP     = Reduction.nrP;
    nrSw    = Reduction.nrSw;
    Psi_P   = Reduction.BasisPOD.Psi_P;
    Psi_Sw  = Reduction.BasisPOD.Psi_Sw;
    rP      = Xs(1:nrP,1);
    rSw     = Xs(nrP+1:nrP+nrSw,1);
    P       = Psi_P*rP;
    Sw      = Psi_Sw*rSw;

%============================================
else % [Full Model]
    Nt      = ceil(length(Xs)/2);
    rP      = 0;
    rSw     = 0;
    P       = Xs(1:Nt,1);
    Sw      = Xs(Nt+1:2*Nt,1);

end
    Solution.Ppast      = Solution.Pcurrent;
    Solution.rPcurrent  = rP;
    Solution.Pcurrent   = P;
    Solution.P          = [Solution.P,P];
    %---------------
    Solution.Swpast     = Solution.Swcurrent;
    Solution.Swcurrent  = Sw;
    Solution.rSwcurrent = rSw;
    Solution.Sw         = [Solution.Sw,Sw];
    %-----------------------------------------
return
