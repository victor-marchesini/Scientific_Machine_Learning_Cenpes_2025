function Properties = update_properties(Properties,Solution)

P  = Solution.Pcurrent;
Sw = Solution.Swcurrent;

% P  = 3000*ones(length(Sw),1);
%============================
% Update components 
[bo bw dbo dbw ddbo ddbw]   = compute_volumetric_factor(Properties,P);
[Uo,Uw,dUo,dUw]             = compute_viscosity(Properties,P);
[kro,krw,dkro,dkrw]         = compute_relative_permeability(Properties,Sw);

%=======================
Properties.bo   = bo;
Properties.bw   = bw;
Properties.dbo  = dbo;
Properties.dbw  = dbw;
Properties.ddbo = ddbo;
Properties.ddbw = ddbw;
Properties.Uo   = Uo;
Properties.Uw   = Uw;
Properties.dUo  = dUo;
Properties.dUw  = dUw;
Properties.kro  = kro;
Properties.krw  = krw;
Properties.dkro = dkro;
Properties.dkrw = dkrw;


