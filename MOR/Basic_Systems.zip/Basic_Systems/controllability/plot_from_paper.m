figure();
for i=1:3
    subplot(3,3,i);
    clim = [[-0.26 0.26]; [-0.73 0.73]; [-0.45 0.45]];       
    imagesc(reshape(Vp(:,i),Nx,Ny), clim(i,:)); 
    colorbar; 
    colormap('jet')
    hold on;
    axis([1 Nx 1 Ny]);             
    set(gca,'xtick',[])
    set(gca,'ytick',[])
    set(gca,'YDir','normal')
    title(join(["Vp",i]))
    plot(Ctrlbhpsub(1,:), Ctrlbhpsub(2,:), 'ro', Ctrlratesub(1,:), Ctrlratesub(2,:), 'k*',  Measbhpsub(1,:), Measbhpsub(2,:), 'gd', 'MarkerFaceColor', [0.5,0.5,0.5], 'MarkerSize', 8)     
end

for i=1:3
    subplot(3,3,i+3);
    clim = [[-0.26 0.26]; [-0.73 0.73]; [-0.45 0.45]]; 
    imagesc(reshape(Vq(:,i),Nx,Ny), clim(i,:)); 
    colorbar;
    colormap('jet')
    hold on;
    axis([1 Nx 1 Ny]);
    set(gca,'xtick',[])
    set(gca,'ytick',[])
    set(gca,'YDir','normal')   
    title(join(["Vq",i]))
    plot(Ctrlbhpsub(1,:), Ctrlbhpsub(2,:), 'ro', Ctrlratesub(1,:), Ctrlratesub(2,:), 'k*',  Measbhpsub(1,:), Measbhpsub(2,:), 'gd', 'MarkerFaceColor', [0.5,0.5,0.5], 'MarkerSize', 8)    
end

for i=1:3
    subplot(3,3,i+6);    
    clim = [[-1230 1230]; [-5200 5200]; [-4930 4930]]; 
    imagesc(reshape(Ti(:,i),Nx,Ny)); 
    colorbar; 
    colormap('jet')
    hold on;
    axis([1 Nx 1 Ny]);
    set(gca,'xtick',[])
    set(gca,'ytick',[])
    set(gca,'YDir','normal')    
    title(join(["T",i]))
    plot(Ctrlbhpsub(1,:), Ctrlbhpsub(2,:), 'ro', Ctrlratesub(1,:), Ctrlratesub(2,:), 'k*',  Measbhpsub(1,:), Measbhpsub(2,:), 'gd', 'MarkerFaceColor', [0.5,0.5,0.5], 'MarkerSize', 8)    
end