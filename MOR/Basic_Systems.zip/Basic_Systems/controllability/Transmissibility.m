function Trans=Transmissibility(Mobility)
global Nx Ny Nz dx dy dz 



% Defining geometry of the reservoir
N=Nx*Ny*Nz;
Ax=dy*dz; Ay=dx*dz; Az=dx*dy;
tx=2*Ax/dx; ty=2*Ay/dy; tz=2*Az/dz;

% Compute transmissibility by harmonic averaging
MobilityMatrix=reshape(Mobility,Nx,Ny,Nz);
L=MobilityMatrix.^(-1);
TX=zeros(Nx+1,Ny,Nz);
TY=zeros(Nx,Ny+1,Nz);
TZ=zeros(Nx,Ny,Nz+1);
TX(2:Nx,:,:)=tx./(L(1:Nx-1,:,:)+L(2:Nx,:,:));
TY(:,2:Ny,:)=ty./(L(:,1:Ny-1,:)+L(:,2:Ny,:));
TZ(:,:,2:Nz)=tz./(L(:,:,1:Nz-1)+L(:,:,2:Nz));

% Assemble TPFA discretization matrix
Tx_pos=reshape(TX(1:Nx,:,:),N,1); Tx_neg=reshape(TX(2:Nx+1,:,:),N,1);
Ty_pos=reshape(TY(:,1:Ny,:),N,1); Ty_neg=reshape(TY(:,2:Ny+1,:),N,1);
Tz_pos=reshape(TZ(:,:,1:Nz),N,1); Tz_neg=reshape(TZ(:,:,2:Nz+1),N,1);

DiagVecs=[Tz_neg, Ty_neg, Tx_neg, -(Tz_pos+Ty_pos+Tx_pos+Tx_neg+Ty_neg+Tz_neg), Tx_pos, Ty_pos, Tz_pos];
DiagIndex=[-(Ny*Nx), -Nx, -1, 0, 1, Nx, (Nx*Ny)];
Trans=spdiags(DiagVecs,DiagIndex,N,N);





