%% Initialization
clear;clc;close all;
global Nx Ny Nz dx dy dz mu Bo rho

%Defining geometry of the reservoir
Nx  = 21; Ny = 21; Nz = 1;
dx  = 10*meter; dy = dx; dz = dx;       % [m]
N   = Nx*Ny*Nz;
dV  = dx*dy*dz;

% Reference Parameters
phi         = 0.2;
mu          = 1e-3*Pascal*second;       % [Pa.s]
rho         = 52*pound/ft^3;
Bo          = 1.;                       % 
Co          = 10e-10/Pascal;            % [Pa^-1]

% Permeability
% Homogenous
k           = 1000*ones(N,1)*milli*darcy; % [mDarcy]
kMatrix     = reshape(k,Nx,Ny,Nz);

%% Heterogenous
% kMatrix=100*milli*darcy*ones(Nx,Ny);
% for i=1:13
%     for j=i+11:Ny
%         kMatrix(i,j)=1000*milli*darcy;
%     end
% end
% for i=13:Nx
%     for j=1:i-12
%         kMatrix(i,j)=10*milli*darcy;
%     end
% end
% kMatrix=kMatrix';


%% Control Wells
Ctrlbhpsub                  = [3 11 19; 19 11 3]; 
Ctrlratesub                 = [19; 19];

Ctrlbhpind                  = sub2ind([Nx,Ny],Ctrlbhpsub(1,:),Ctrlbhpsub(2,:));
Ctrlbhpvec                  = Sub2Vec(Nx,Ny,Ctrlbhpsub(1,:),Ctrlbhpsub(2,:)); 
Ctrlrateind                 = sub2ind([Nx,Ny],Ctrlratesub(1,:),Ctrlratesub(2,:));
Ctrlratevec                 = Sub2Vec(Nx,Ny,Ctrlratesub(1,:),Ctrlratesub(2,:));

CtrlWIbhp                   = zeros(N,1); 
CtrlWIbhp(Ctrlbhpind)       = WI(kMatrix(Ctrlbhpind));
Jpc                         = spdiags(CtrlWIbhp,0,N,N);
CtrlWIrate                  = zeros(N,1);
CtrlWIrate(Ctrlrateind)     = WI(kMatrix(Ctrlrateind));
Jqc                         = spdiags(CtrlWIrate,0,N,N);

%% Measurement Wells 
Measbhpsub                  = [3; 3]; 
Measratesub                 = [3 11 19; 19 11 3];

Measbhpind                  = sub2ind([Nx,Ny],Measbhpsub(1,:),Measbhpsub(2,:));
Measbhpvec                  = Sub2Vec(Nx,Ny,Measbhpsub(1,:),Measbhpsub(2,:)); 
Measrateind                 = sub2ind([Nx,Ny],Measratesub(1,:),Measratesub(2,:));
Measratevec                 = Sub2Vec(Nx,Ny,Measratesub(1,:),Measratesub(2,:));

MeasWIbhp                   = zeros(N,1);
MeasWIbhp(Measbhpind)       = WI(kMatrix(Measbhpind)); 
Jpo                         = spdiags(MeasWIbhp,0,N,N);
MeasWIrate                  = zeros(N,1);
MeasWIrate(Measrateind)     = WI(kMatrix(Measrateind));
Jqo                         = spdiags(MeasWIrate,0,N,N);

%% Fluid flow matrices
% Mobility Matrix
Mobility                    = kMatrix/(Bo*mu);

% Transmissibility Matrix
T                           = Transmissibility(Mobility);
T                           = T-Jpc;

% Accumulation Matrix
Acc_diag                    = (Co*phi*dV/Bo)*ones(N,1);
Acc                         = spdiags(Acc_diag,0,N,N);

%% State Space Form
Ac                  = Acc\T;

CtrlScale           = Jqc(Ctrlrateind(1),Ctrlrateind(1)); % Scale Factor: WI of the first rate control well
Bc                  = -Acc\[Ctrlratevec.*CtrlScale, 0.*Measbhpvec, -Jpc(:,Ctrlbhpind)];

MeasScale           = Jqo(Measrateind(1),Measrateind(1)); % Scale Factor: WI of the first rate measurment well
C                   = [0.*Ctrlratevec'; Measbhpvec'.*MeasScale;Jqo(Measrateind,:)];

D                   =  blkdiag(0,...
                                -(Jpo(Measbhpind,Measbhpind))^(-1),...
                                -Jqo(Measrateind,Measrateind));

sys                 = ss(full(Ac),full(Bc),full(C),full(D));

%% Definition of Controls
t = 0:1:100;

u_rate=[repmat(5E6*stb/day,1,70) repmat(0*stb/day,1,31)]; 
u_pressure = [repmat(0*psia,1,30) repmat(100*psia,1,40) repmat(0*psia,1,31)]; 
Lqu = [1 0 0 0 0]';
Lpu = [0 0 1 1 1]';
u = u_rate./CtrlScale.*Lqu + u_pressure.*Lpu;

[y,t,X] = lsim(sys, u, t);

wells = [61 45 221 397 381];
wells_names = ["Well 1", "Well 2", 'Well 3', 'Well 4', 'Well 5'];

wells_u = [397 45 381 221 61];
wells_y = [397 45 381 221 61];


%% Plot 
figure('units','normalized','outerposition',[0 0 1 1])
for i = 1:5
    if ismember(wells(i),wells_u)
        if ~ismember(wells(i), [Ctrlrateind Ctrlbhpind])
            continue
        end
        subplot(5,2,(i-1)*2+1);
        ind_in_u = find(wells_u == wells(i));
        if ismember(wells(i),Ctrlrateind)
            type = 'Rate' ;
            plot(t,convertTo(u(ind_in_u,:).*CtrlScale,stb/day ));                        
            ylabel('Rate (stb/day)')
        else
            type = 'BHP';
            plot(t, convertTo(u(ind_in_u, :), psia), 'DisplayName','BHP'); hold on
            plot(t, convertTo(X(:, wells(i)), psia), 'r--','DisplayName','gridblock')
            legend('Location','best')            
            ylabel('Pressure (psia)');
        end         
        title(join(["Control ",type,": ",wells_names(i)],""));        
    end
end

for i = 1:5
    if ismember(wells(i),wells_y)
        if ~ismember(wells(i), [Measrateind Measbhpind])
            continue
        end
        subplot(5,2,(i-1)*2+2);
        ind_in_y = find(wells_y == wells(i));
        if ismember(wells(i),Measrateind)
            type = 'Rate';
            plot(t,convertTo(y(:,ind_in_y),stb/day));
            ylabel('Rate (stb/day)');
        else
            type = 'BHP';
            plot(t,convertTo(y(:,ind_in_y)./MeasScale,psia),'DisplayName','BHP');hold on
            plot(t,convertTo(X(:,wells(i)),psia),'r--','DisplayName','gridblock')                        
            legend('Location','best');
            ylabel('Pressure (psia)');
        end        
        title(join(["Measure ",type,": ",wells_names(i)],""));                
    end
end
 
%% Plot MAP
figure
clims = [-100 70];
h = imagesc(convertTo(reshape(X(1,:),[21,21]),psia), clims);
for i = 1:101    
    set(h,'cdata',convertTo(reshape(X(i,:),[21,21]),psia))    
    text(4,3, sprintf('Well 2\nNo Control\nObs BPH')); 
    text(4,19, sprintf('Well 1\nControl BHP\nObs RATE')); 
    text(18,3, sprintf('Well 5\nControl BHP\nObs RATE'), 'HorizontalAlignment', 'right'); 
    text(12,11, sprintf('Well 3\nControl BHP\nObs RATE')); 
    text(18,19, sprintf('Well 4\nControl RATE\nNo Obs'), 'HorizontalAlignment', 'right');
    hold on; 
    plot(Ctrlbhpsub(1,:), Ctrlbhpsub(2,:), 'ro', Ctrlratesub(1,:), Ctrlratesub(2,:), 'k*',  Measbhpsub(1,:), Measbhpsub(2,:), 'gd', 'MarkerFaceColor', [0.5,0.5,0.5], 'MarkerSize',10  ) 
    set(gca,'YDir','normal')
    title(['X, t = ',sprintf('%d',i)])
    colorbar
    colormap('jet')
    drawnow;
end
