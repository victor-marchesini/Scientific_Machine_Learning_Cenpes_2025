function y=WI(k)
global dx dz mu Bo rho
rw          = 0.1*meter;                % [m]
re          = 0.208*dx;                 % [m] 
y=(2*pi*dz*rho*k)/(mu*Bo*(log(re/rw)));