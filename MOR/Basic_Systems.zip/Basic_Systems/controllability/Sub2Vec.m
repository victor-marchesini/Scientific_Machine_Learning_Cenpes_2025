function Wij=Sub2Vec(Nx,Ny,x,y)
    NZMAX       = length(x);
    Wij         = spalloc(Nx*Ny,1,NZMAX);
    Ind         = sub2ind([Nx,Ny], x, y);
    Wij(Ind)    = 1;   
end