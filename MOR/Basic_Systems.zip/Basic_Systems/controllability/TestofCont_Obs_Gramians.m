% Show Controllability/Observability
clear all

A = [1 3; -1 -2];
B = [1;0];
C = [0 1];
D = 0;

sys = ss(A, B, C , D);

% Stable? 
[V, lamb] = eig(A);

% Two ways to compute gramians
% Use Lyap computations

%X = lyap(A,Q) solves the Lyapunov matrix equation: A*X + X*A' + Q = 0
XP = lyap(A, B*B');

% X = R'*R
RP = lyapchol(A,B*B');
XQ = lyap(A', C'*C);
RQ = lyapchol(A',C'*C);

% Use gramians functions directly
%Wc = gram(SYS,'c';  Wo = gram(SYS,'o'); 
P = gram(sys,'c');
Q = gram(sys,'o');

% Eigs of P, Q
% Matlab --> By default eig does not always return the eigenvalues and eigenvectors in sorted order. 
% Need to sort

[VP, lambP] = eig(P);
[lambP_sort,ind1] = sort(diag(lambP), 'descend')
VPsort = VP(ind1, ind1)


[VQ, lambQ] = eig(Q);
[lambQ_sort,ind2] = sort(diag(lambQ), 'descend')
VQsort = VQ(ind2, ind2)

% Plot eigenvectors
plot([0, VP(1,2)], [0, VQ(:, 1)]);
axis([0  2    0  2])
grid


%% Cros Gramians
X = VQ'*VP

%% BALANCING THE SYSTEM - CREATE P=Q=DIAG(SIGMA)

[sysB,HSV, T] = balreal(sys);
Pb = gram(sysB,'c');
Qb = gram(sysB,'o');

% Do they have the same transfer function?
TFsys = tf(sys);
TFsysB = tf(sysB);

% How to compute a balance transformation? (Naive Implementation)
% Given--> P = S^T*S; Q = R^T*R (Cholesky decompositions
% Compute --> SR^T = U*Sigma*V' --> SVD(SR^T)
% Tb :=  Sigma^(-1/2)*V^T*R
[U1, S1, V1] = svd(RP*RQ');
Tb = S1^(-1/2)*V1'*RQ;

%%

