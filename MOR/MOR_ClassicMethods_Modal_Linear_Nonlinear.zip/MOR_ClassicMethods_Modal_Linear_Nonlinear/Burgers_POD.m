%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% Model Reduction of Dynamical Systems %%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%       Summer Semester  2019          %%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Exercise 5, Problem 1,2 : Nonlinear Model Order Reduction (POD-DEIM)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 1 : Solve full order system

    n                = 500; % Order of full system
    mu               = 0.05; % Viscosity
    [A,B,C,H,N,f,x0] = Burgers_input_matrices(n,mu);

    % Time span
    tstart   = 0;
    tend     = 10;
    time     = linspace(tstart,tend,100);
    u        = @(t) cos(pi*t);

    % Setup the Differential equation
    dx1            = @(t,x,A,H,N,B) A*x + H*f(x) + B*u(t) + N*u(t)^2;
    options        = odeset('RelTol',1e-8,'AbsTol',1e-12);

    % Use ode15s to solve the system and obtain snapshots X in a matrix

    % Plot output trajectory
    y = 
    plot();

% Step 2 : Form projection matrix V and obtain reduced order system

    r = 30; % Order of reduced system

    % Use SVD to extract the singular vectors of the snapshot matrix X
    % Form the projection matrix V of rank r
    V  = 

    % Reduced matrices
    Ar = V'*A*V;
    Br = V'*B;
    Cr = C*V;
    Hr = V'*H;
    Nr = V'*N;
    z0 = V'*x0;

    dxpod              = @(t,z,Ar,Hr,Nr,B) Ar*z + Hr*f(V*z) + Br*u(t) + Nr*u(t)^2;

    % Solve the reduced system and generate the snapshots
    
    % Plot the reduced output trajectory

% Step 3 : Implement DEIM (Problem 2)


    % DEIM: Get nonlinear snapshots
    % Form U, P matrices
