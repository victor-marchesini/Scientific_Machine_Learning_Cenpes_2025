function [A,B,C,H,N,f,x0] = Burgers_input_matrices(n,mu)
    
    h  = 1/(n+1);
    k1 = mu/(h^2);
    k2 = 1/(2*h); 

    A = gallery('tridiag',n, k1, -2*k1 , k1);
    A(end,end) = -k1; % Neumann Boundary condition
    
    B = sparse(n,1); B(1)   = k1;
    C = sparse(1,n); C(end) = 1;
    N = sparse(n,1); N(1)   = k2;
    
    H = gallery('tridiag',n, k2, -k2 , 0);
    f = @(x) (x.^2);
    
    x0 = zeros(n,1);
end