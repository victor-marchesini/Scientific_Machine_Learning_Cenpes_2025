% Simulation of the CDplayer
% Based on the Gugercin paper
clear all
%close all

load CDplayer

[n,n]  =size(A);
% Grimme thesis
Bg= B(:,2);
Cg = C(1, :);
Dg = 0;
sysg  = ss(full(A), Bg, Cg, Dg);
B = Bg;
C = Cg;
D = Dg;
sys = sysg;


% % Serkan thesis
% B = B(:,1);
% C = C(1,:);
% D = 0;
% %D = zeros(2);
%sys = ss(full(A), B, C,D);


% Controller Design

% V= 1e-5;
% W = 1;
% G = ones(120,1);
% Q11 = 1e-5*eye(60);
% Q = 1e-5*eye(120);
% %Q = blkdiag(Q11, zeros(60));
% R = 1;

V= 1e-2;
W = 1e-3;
G = ones(120,1);
Q11 = 1e0*eye(60);
Q = 1e2*eye(120);
%Q = blkdiag(Q11, zeros(60));
R = 1;

K = lqr(A, B, Q, R);
L = lqe(A, B, C, W, V);

Ac = A- B*K - L*C + L*D*K;
Bc = L;
Cc = -K;
Dc = 0;

syscont = ss(Ac, Bc, Cc, Dc);
syscl = feedback(sys, syscont, 1);
sysol= series(syscont, sys);

r = 20;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Controller Reduction - Balanced Truncation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Need to compute  --> || Wo (K-Kr) Wi ||_inf

fwbt = 1;
if fwbt == 0
    % For one-sided frequencyt weighted
    % Wi = G*inv(I+G*K)
    % Wo = I
    Wi = sys/(ss([],[],[],1)+ sys*syscont);
    Wi = minreal(Wi);
    Wo = ss([],[],[], eye(1));
    Wo = minreal(Wo);
else
    % For two-sided weights
    % Wo = inv(I + G*K)*G
    % Wi = inv(I+G*K)
    Wi = (ss([],[],[],1)+ sys*syscont)\sys;
    Wi = minreal(Wi);
    Wo = inv(ss([],[],[],1)+ sys*syscont);
    Wo = minreal(Wo);
end

[Ai, Bi, Ci, Di] = ssdata(Wi);
[Ao, Bo, Co, Do] = ssdata(Wo);


Ai_bar = [Ac Bc*Ci;zeros(length(Bi),length(Cc)), Ai];
Bi_bar = [Bc*Di;Bi];
Ci_bar = [Cc Dc*Ci];
Di_bar = Dc*Di;
sysGWi = ss(Ai_bar, Bi_bar, Ci_bar, Di_bar);

Ao_bar = [Ac zeros(length(Bc), length(Co)); Bo*Cc Ao];
Bo_bar = [Bc;Bo*D];
Co_bar = [Do*Cc Co];
Do_bar = Do*Dc;
sysWoG = ss(Ao_bar, Bo_bar, Co_bar, Do_bar);


% Define the reachability gramian as P = U * U'  --> it is in the schur form
[Qr, Rr] = schur(Ai_bar, 'real');
Up = lyapUR(Rr, Qr'*Bi_bar);
Up = Qr*Up;

U = Up(1:120, :);

% Define the observability gramian as Q = L * L'
[Qo, Ro] = schur(Ac, 'real');
Lp = lyapSL(Ro, Cc*Qo);
Lp = Qo*Lp;

L = Lp(1:120, :);

% % Balance and Truncate --> sqrta
[Ar_SR, Br_SR, Cr_SR, Dr_SR, Tr_SR, Tir_SR, HSV] = sqrta_BT(Ac, Bc, Cc,Dc,U, L, r, 1);
sysr_cont = ss(Ar_SR, Br_SR, Cr_SR, Dr_SR);
sysclr = feedback(sys, sysr_cont, 1);
sysolr= series(sysr_cont, sys);


% Usind directly SLICOT
%[Acr,Bcr,Ccr,Dcr,HSVC,info] = CONRED(meth,Ac,Bc,Cc,Dc,A,B,C,D,...
%                                         tol,discr,ord,alpha)

[Acr,Bcr,Ccr,Dcr,HSVC,info] = conred(1114,Ac,Bc,Cc,Dc,full(A),B,C,D,[],0,r);

syscontr = ss(Acr, Bcr, Ccr, Dcr);
sysclrs = feedback(sys, syscontr, 1);
sysolrs= series(syscontr, sys);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Controller Reduction - Krylov
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% sys_G = pck(full(A),B,C,D);
% sys_K = pck(Ac, Bc, Cc, Dc);
% 
% sys1 = mmult(sys_G, sys_K);
% [sys_type, mr, mc, num] = minfo(sys1);
% 
% sysI = pck([],[],[], eye(mr, mc));
% %sys2 = msub(sysI, sys1);
% sys2 = msub(sysI, sys1);
% 
% Wi = mmult(sys_G, minv(sys2));
% Wo = sysI;
% 
% [Ai, Bi, Ci, Di] = unpck(Wi);
% [Ao, Bo, Co, Do] = unpck(Wo);
% 


% 

% [Acl, Bcl, Ccl, Dcl] = ssdata(syscl);
% 
% % Compute the interpolation points 
% [sres, pol_cl] = residue_ss(Acl,Bcl,Ccl);
% % r = 10;
% % S_cl = -cjt(pol_cl(n-2*r+1:n));
% [sres, pol_K] = residue_ss(Ac,Bc,Cc);
% % r = 10;
% % S_K = -cjt(pol_K(n-2*r+1:n));
% 
% % let's look at the poles first.  --> make the residues (resp. poles) to be in descending
% % order to be easier to see.
% pol_cl = flipud(pol_cl);
% pol_K = flipud(pol_K);
% 
% S = [-pol_cl(7)', -pol_K(1)', -pol_cl(1:6)', -pol_cl(8:17)' -pol_K(3:8)'];
% %S = [-pol_cl(7)', -pol_K(1)', -pol_cl(1:6)', -pol_cl(8:21)' -pol_K(3:8)'];
% %S = [-cjt(pol_cl(1:2)), -cjt(pol_cl(4:17)),  -cjt(pol_K(2:9)), -cjt(pol_K(11:16))];
% %S = [-cjt(pol_cl(1:9)) -cjt(pol_K(1:9))];
% 
% [Acr, Bcr, Ccr, Dcr] = IRKA_controller(Ac, Bc, Cc, Dc, S);
% 
% r = 18;
% om = logspace(1,5,r);
% %om = [0.157 75 309 1.66e3 5.33e3 1.09e4 2.52e4 3.91e4 4.3e4 6.34e4 8.19e4 7.0e5 1.44e4 1e6];
% Som = [];
% for i = 1:12,
%     Som = [Som [om(i)*j -om(i)*j]];
% end
% 
% S = Som;
% 
% [V1, Z1, V_c, Z_c] = RK_DRA(Ac, Bc, Cc,Dc,1,[S(1:length(S)/2)]);  
% [V2, Z2, V_c, Z_c] = RK_DRA(Ac, Bc, Cc,Dc,1,[S(length(S)/2 + 1:length(S))]);
% V = V1;
% Z = Z2/(V1'*Z2);
% 
% Acr = Z'*Ac*V;
% Bcr = Z'*Bc;
% Ccr = Cc*V;
% Dcr = Dc;
% 
% syscr_K = ss(Acr, Bcr, Ccr, Dcr);
% sysclr_K = feedback(sys, syscr_K, 1);
% [Aclr, Bclr, Cclr, Dclr] = ssdata(sysclr_K);
% p1 = pole(sysclr_K)
% sysolr_cont_Krylov = series(syscr_K, sys);
% bodemag(sysolr_cont_Krylov, 'g')

