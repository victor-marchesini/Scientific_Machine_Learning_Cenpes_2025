function [Ar,Br,Cr,iter] = IRKA_gen(E,A,B,C,r,maxiter,tol)

m = size(B,2);
p = size(C,1);
S = rand(r,1);
Tb = rand(m,r);
Tc = rand(p,r);
 
err = 1;
iter = 0;
while ( err > tol && iter < maxiter)
    S_old = S;
    for i = 1 : r
        V(:,i) = (S(i)*E-A)\(B*Tb(:,i));
        W(:,i) = (S(i)*E'-A')\(C'*Tc(:,i));
    end
    W = E'*W;
    [V,dummy,dummy] = svd(full([real(V) imag(V)]),0);
	[W,dummy,dummy] = svd(full([real(W) imag(W)]),0);

	V = V(:,1:r);
    W = W(:,1:r);
    
    Ar = (W'*V)\((W'/E)*(A*V));
    Br = (W'*V)\((W'/E)*B);
    Cr = C*V;
   
    [T,S] = eig(Ar);
    S = - diag(S);
    Tb = (T\Br)';
    Tc = Cr*T;
    
	err = norm(S-S_old)/norm(S_old);
    iter = iter + 1;
    %% comment out for non-verbose mode %%
    fprintf('IRKA step %d, conv. crit. = %e \n', iter, err)
end
if (iter == maxiter && err > tol),
  fprintf('IRKA: No convergence in %d iterations.\n', maxiter)
end