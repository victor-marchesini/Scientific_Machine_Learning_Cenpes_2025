function [Ar,Br,Cr,iter] = IRKA(A,B,C,r,maxiter,tol)

n = size(A,1);
m = size(B,2);
p = size(C,1);
I = speye(n);
S = rand(r,1);
Tb = rand(m,r);
Tc = rand(p,r);

err = 1;
iter = 0;
while ( err > tol && iter < maxiter)
    S_old = S;
    for i = 1 : r
        V(:,i) = (S(i)*I-A)\(B*Tb(:,i));
        W(:,i) = (S(i)*I-A')\(C'*Tc(:,i));
    end
    [V,~,~] = svd(full([real(V) imag(V)]),0);
	[W,~,~] = svd(full([real(W) imag(W)]),0);

	V = V(:,1:r);
    W = W(:,1:r);
    
    Ar = (W'*V)\(W'*A*V);
    Br = (W'*V)\(W'*B);
    Cr = C*V;
   
    [T,S] = eig(Ar);
    S = - diag(S);
    Tb = (T\Br)';
    Tc = Cr*T;
    
    err = norm(S-S_old)/norm(S_old);
    iter = iter + 1;
    %% comment out for non-verbose mode %%
    fprintf('IRKA step %i, conv. crit. = %d \n', iter, err)
end
if (iter == maxiter && err > tol),
  fprintf('IRKA: No convergence in %d iterations.\n', maxiter)
end