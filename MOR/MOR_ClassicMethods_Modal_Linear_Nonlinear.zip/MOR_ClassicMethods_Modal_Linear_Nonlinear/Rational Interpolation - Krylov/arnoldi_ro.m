function [V,H,r] = arnoldi_ro(A, m, v)

% function H = arnoldi_ro(A, m, v)
% function [V,H] = arnoldi_ro(A, m, v)
% function [V,H,r] = arnoldi_ro(A, m, v)
%
% This function computes the Arnoldi factorization using modified
% Gram-Schmidt with Daniel et al. re-orthgonalization, as
% implemented by Sorensen.
%
% A   the matrix (must be specified)
% v   the starting vector (default: standard normal random entries)
% m   the number of Arnoldi steps to return (default: dim(A))
%
% m and v can be given in any convenient order
% 
% V   n-by-m matrix with orthogonal columns.
%     The first j columns span the j-th Krylov subspace.
% H   m-by-m upper Hessenberg matrix.
% r   n-vector, r = h_{m+1,m} v_{m+1} 
% 
% Overall, we should have A V - V H = r e_m' to high precision.
%
% email bugs to embree@rice.edu

[n n] = size(A);

if (nargin == 3)
   if (length(m) > 1), tmp = v; v = m; m = tmp; end;
elseif (nargin == 2)
   if (length(m) > 1), v = m; m = n; 
   else v = randn(n,1); end;
elseif (nargin == 1)
   v = randn(n,1);
   m = n;
end;
m = min(n,m);
tol = 5e-15;

V = v/norm(v);
for k=1:min(m,n-1)
   V(:,k+1) = A*V(:,k);
   for j=1:k
      H(j,k)   = V(:,j)'*V(:,k+1);
      V(:,k+1) = V(:,k+1) - H(j,k)*V(:,j);
   end;
   H(k+1,k) = norm(V(:,k+1));
   r        = V(:,k+1);

% reorthogonalization
   s = V(:,1:k)'*r; r = r - V(:,1:k)*s; H(1:k,k) = H(1:k,k)+s; 
   passes = 0;
   while ((norm(s) > tol*norm(r)) & (passes < 3))
      s = V(:,1:k)'*r; r = r-V(:,1:k)*s; H(1:k,k) = H(1:k,k)+s;
      passes = passes+1;
   end
   if (norm(s) > max(tol,1e-15)*norm(r))     % only flag flagrant violations
      fprintf('ARNOLDI_EXT: canceled re-orthgonalization: %10.5e > tol = %10.5e\n', ...
              norm(s)/norm(r), tol);
   end
   H(k+1,k) = norm(r);         
   V(:,k+1) = r/norm(r);
%   fprintf('finished arnoldi iteration %d/%d\n', k, min(m,n-1));
end

if (m>=n), H(:,m) = V(:,1:m)'*A*V(:,m);end;
V = V(:,1:m);
H = H(1:m,1:m);

