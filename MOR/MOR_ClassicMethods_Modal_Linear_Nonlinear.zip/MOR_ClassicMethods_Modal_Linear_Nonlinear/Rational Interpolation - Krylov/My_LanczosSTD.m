function [V, W] = My_LanczosSTD(A,B,C,m);
% Standard non Symmetric Lanczos Algorithm.
% Computed from the thesis
%
%   Input:  A -- an n by n matrix  
%           B -- an n by vector    --> (A,B,C) is a realization of the
%                                       system to be decomposed
%           C -- an 1 by n vector 
%           m -- a positive integer(m << n) 
%
%   Output: V, W -- a n by m biotthogonal matrices


n = length(B);
eps =10^(-16);


%line 1


beta = sqrt(abs(C*B));
beta_vec = [beta];  
delta = beta*sign(C*B);
delta_vec = [delta];

% line 2
v= B/delta;
w = C'/beta;
v0 = zeros(length(B),1);
w0 = zeros(length(B),1);
V(:,1) = [v];
W(:,1) =  [w];


% line 3
for j = 1:m-1
    % line 4  
    alpha = w'*A*v;

    % line 5
    if j == 1,
        v_hat = A*v - alpha*v - beta*v0; v_hat = v_hat - V*(W'*v_hat);
        w_hat = A'*w - alpha*w - delta*w0; w_hat = w_hat - W*(V'*w_hat);
    else 
    v_p = V(:,j-1);
    v_hat = A*v - alpha*v - beta*v_p;
    v_hat = v_hat - V*(W'*v_hat);

    % line 6
    w_p = W(:,j-1);
    w_hat = A'*w - alpha*w - delta*w_p;
    w_hat = w_hat - W*(V'*w_hat);
    end
    % line 7
    beta = sqrt(abs(w_hat'*v_hat));
    beta_vec = [beta_vec beta];
        % line 8-10

    if beta < eps
        disp('breakdown has ocuured')
    else
    % line 11
    delta = beta*sign(w_hat'*v_hat);
    delta_vec = [delta_vec delta];
    %line 12
    v = v_hat/delta;
    V = [ V, v];
    w = w_hat/beta;
    W = [W, w];
    end
end

 