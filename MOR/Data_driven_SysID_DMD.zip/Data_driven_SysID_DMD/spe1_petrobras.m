%Dimitrios Voulanas
%dvoulanas@tamu.edu, dvoulanas@yahoo.com
%PETE Department, Texas A&M University
%% Clear workspace and figures
clear; clc; close all;

%% Load MRST modules required for black-oil simulation and deck processing
mrstModule add ad-core ad-blackoil ad-props deckformat mrst-gui test-suite

%% Set up the SPE1 benchmark case
% G: grid structure, rock: rock properties, fluid: fluid model,
% deck: input deck, state0: initial reservoir state
[G, rock, fluid, deck, state0] = setupSPE1();

%% Build the AD model and convert the deck schedule
% model: automatic differentiation black-oil model
model    = selectModelFromDeck(G, rock, fluid, deck);
% schedule: MRST-formatted time schedule and control steps (sec)
schedule = convertDeckScheduleToMRST(model, deck);

%% Refine simulation steps: daily for first 3 months, then monthly
daySec    = 24*3600;             % one day in seconds
monthSec  = 30*daySec;           % monthly interval (30 days)
totalSec  = sum(schedule.step.val);

% First segment: daily steps up to 3 months
seg1Sec   = 3*monthSec;          % first three months
seg1Sec   = min(seg1Sec, totalSec);
Nday1     = floor(seg1Sec/daySec);
daily1    = repmat(daySec, Nday1, 1);
rem1      = seg1Sec - Nday1*daySec;
if rem1>0, daily1(end+1)=rem1; end

% Second segment: monthly steps for remainder
remSec    = totalSec - sum(daily1);
Nmon2     = floor(remSec/monthSec);
monthly2  = repmat(monthSec, Nmon2, 1);
rem2      = remSec - Nmon2*monthSec;
if rem2>0, monthly2(end+1)=rem2; end

% Combine new step durations
newVal    = [daily1; monthly2];
newNsteps = numel(newVal);

% Map controls: assign each new step the original control at its end time
origCum   = cumsum(schedule.step.val);
newCum    = cumsum(newVal);
newCtrl   = zeros(newNsteps,1);
for i=1:newNsteps
    t_end = newCum(i);
    idx   = find(origCum>=t_end,1,'first');
    newCtrl(i) = schedule.step.control(idx);
end

% Update schedule with refined steps
schedule.step.val     = newVal;
schedule.step.control = newCtrl;

%% Run the simulation with refined schedule
nls = NonLinearSolver('useLinesearch', true);
[ws, states] = simulateScheduleAD(state0, model, schedule, 'NonlinearSolver', nls);

%% Compute cumulative times and plot vector
time_cum = [0; cumsum(schedule.step.val)];   % (sec)
time_vec = time_cum(2:end);                   % match ws entries

%% Select snapshots: pick one snapshot at each month boundary
maxSec    = time_cum(end);
monthEdges= monthSec:monthSec:floor(maxSec/monthSec)*monthSec;
% find nearest step index for each month edge
dx_month = arrayfun(@(t) find(abs(time_cum - t)==min(abs(time_cum - t)),1), monthEdges);
snapshot_idx = unique([1; dx_month(:)]);

%% Preallocate snapshot arrays for monthly output
Ncells   = numel(state0.pressure);
Nsnap    = numel(snapshot_idx);
P_mon    = zeros(Ncells, Nsnap);
W_mon    = zeros(Ncells, Nsnap);
O_mon    = zeros(Ncells, Nsnap);
G_mon    = zeros(Ncells, Nsnap);

%% Extract pressure and saturations at selected snapshots
for j=1:Nsnap
    idx = snapshot_idx(j);
    if idx==1
        P_mon(:,j)=state0.pressure;
        W_mon(:,j)=state0.s(:,1);
        O_mon(:,j)=state0.s(:,2);
        G_mon(:,j)=state0.s(:,3);
    else
        sIdx = idx-1;
        P_mon(:,j)=states{sIdx}.pressure;
        W_mon(:,j)=states{sIdx}.s(:,1);
        O_mon(:,j)=states{sIdx}.s(:,2);
        G_mon(:,j)=states{sIdx}.s(:,3);
    end
end

%% Plot well solutions (daily and monthly control) vs time
figure;
plotWellSols(ws, time_vec);
title('Well solutions vs. time');
xlabel('Time [days]'); ylabel('Rate / Pressure');

%% Visualize monthly gas saturation
figure;
view(35,40);
for j=2:Nsnap
    idx = snapshot_idx(j);
    t   = time_cum(idx)/daySec;
    [az,el] = view(); clf;
    plotWell(G, schedule.control.W);
    plotCellData(G, G_mon(:,j),'FaceAlpha',0.6,'EdgeAlpha',0.1,'EdgeColor','k');
    title(sprintf('Month %d at day %.0f', j, t));
    axis tight off; colorbar; view(az,el); pause(0.3);
end
