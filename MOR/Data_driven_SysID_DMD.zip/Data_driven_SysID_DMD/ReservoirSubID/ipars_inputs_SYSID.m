   
% build uniform distribution
%r = a + (b-a).*rand(100,1);
% for plotting --> stairs
clear all
close all
%rand('state',0);
rand('state',5);

Tf = 180;
% Injector 1
% rate 30;
% interval --> [75, 125]
a = 30;
b = 40;
I1 = a + (b-a).*rand(Tf,1);
stairs(I1);
hold on

% Save data
% crude way
I1_data = [];
for i=1:1:Tf,
    I1_data_row = [I1_data [i-1 I1(i)]];
end
t = 1:1:Tf;
t1 = t-1;
v(1:Tf,1) = ',';
I1_data_column = [t1' I1(1:1:Tf)];
II1 = [num2str(I1_data_column, '%10.5f') v(1:1:Tf)];

% Injector 2
rand('state',1);
% rate 100;
% interval --> [75, 125]
I2 = a + (b-a).*rand(Tf,1);
stairs(I2, 'r');

% Save data
% crude way
I2_data = [];
for i=1:1:Tf,
    I2_data_row = [I2_data [i-1 I2(i)]];
end
I2_data_column = [t1' I2(1:1:Tf)];
II2 = [num2str(I2_data_column, '%10.5f') v(1:1:Tf)];

% Producer 1
% rate 70;
% interval --> [40, 70 ]
rand('state',2);
a = 26;
b = 34;

P1 = a + (b-a).*rand(Tf,1);
figure
stairs(P1);
hold on

% Save data
% crude way
P1_data = [];
for i=1:1:Tf,
    P1_data_row = [P1_data [i-1 P1(i)]];
end

P1_data_column = [t1' P1(1:1:Tf)];
PP1 = [num2str(P1_data_column, '%10.5f') v(1:1:Tf)];

% Producer 2
rand('state',3);
P2 = a + (b-a).*rand(Tf,1);
stairs(P2,  'r');
% Save data
% crude way
P2_data = [];
for i=1:1:Tf,
    P2_data_row = [P2_data [i-1 P2(i)]];
end

P2_data_column = [t1' P2(1:1:Tf)];
PP2 = [num2str(P2_data_column, '%10.5f') v(1:1:Tf)];


%vU = [II1 II2 PP1 PP2];
