function [ ] = writeiparsK(X,string)
%
% Write the pre-postprocessing perm files for IPARS format
%
% call: writeipars(X,i)
% where X, is the perm array and 
% string, is an index indicator
%
%  Resulting files are placed into the IPARS work directory
%
%
%
path = '..\Outputs\';
[nx ny nz] = size(X);
%disp(['Dimensions for IPARS: ' num2str(nx),' ',  num2str(ny),' ', num2str(nz)]); 
name = '';
tit =  'XPERM1';
fid = fopen([path name string '.dat'],'w');
va = max(max(max(X)));
for i = 1:nx
   str1 = [tit '( ' num2str(i) ',,) ='];
   fprintf(fid,'%s\n',str1);
   for j = 1: ny
      str2 = ['$ ROW  ' num2str(j)];
      fprintf(fid,'%s\n',str2);
      tt = nz/5;
      for k = 1:tt
          l1 = 5*(k-1) + 1;
          l2 = 5*k;
          y = X(i,j,l1:l2);
          if (va > 1)
             fprintf(fid,'  %6.6f ',y);
          else
             fprintf(fid,'  %5.6f ',y);
          end
          fprintf(fid,'%s\n','');
      end
      l1 = nz - rem(nz,5) + 1;
      l2 = nz;
      if (l2 >= l1)
          y = X(i,j,l1:l2);
          if (va > 1) 
             fprintf(fid,'  %6.4f ',y);
          else
             fprintf(fid,'  %5.4f ',y);
          end
          fprintf(fid,'%s\n','');
      end          
  end
end
fclose(fid);
